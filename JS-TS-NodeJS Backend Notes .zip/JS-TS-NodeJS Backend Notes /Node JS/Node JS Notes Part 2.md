### WebSocket

WebSockets provide a powerful mechanism for real-time communication between clients and servers, particularly in web applications. This protocol allows for full-duplex communication, meaning that data can be sent and received simultaneously over a single connection.

**WebSockets are a protocol that enables persistent, two-way communication channels over a single TCP connection. This is particularly useful for applications that require real-time updates, such as chat applications, online gaming, or live data feeds.**

`Process` 

- The WebSocket protocol begins with a handshake initiated by the client, which requests to upgrade the connection from HTTP to WebSocket.

- If the server supports WebSockets, it accepts the request, and a continuous connection is established

##### Pooling in Default Client-Server Communication

**Polling** is a technique used in traditional web applications to fetch updates from the server at regular intervals. There are two primary types of polling: long polling and short polling.

###### Short Polling

* **Process**: The client sends regular HTTP requests to the server at fixed intervals (e.g., every few seconds).

###### Long Polling:

* **Process**: The client sends a request to the server, and the server holds the request open until new data is available.

##### WebSockets vs. Polling

* **Connection**: WebSockets maintain a persistent connection, while polling repeatedly opens and closes connections.
* **Latency**: WebSockets provide low-latency communication, whereas polling introduces delay.
* **Efficiency**: WebSockets are more efficient as they avoid the overhead of HTTP requests.

Library required is **socket.io** | socket here means the client. 

 ![merixstudio.com](https://cdn.prod.website-files.com/65a07d647e60af8661b7856f/65bfd0eb7360c2afeed1674d_real-time-communication.png)

We use server.listen instead of app.listen = WebSockets require a persistent connection between the client and server, which is **established through an initial HTTP handshake**. Once this handshake is complete, the connection is upgraded to a WebSocket connection. Using `http.createServer(app)` allows you to handle this upgrade request properly.

**IMPORTANT** : In Socket.IO, the `.on` method is used to listen for events, effectively "catching" messages sent from the other side. The `.emit` method is used to send messages or trigger events.

```javascript
socket.emit("chat message", value);
socket.on("chat message", function(message){})
```

**Backend**

```javascript
const {Server} = require("socket.io");

const express = require("express");
const app = express();
const path = require("path");

app.use(express.static(path.resolve("./public")));

const http = require("http");
const server = http.createServer(app);
/*
    - This line initializes the Socket.IO server and attaches it to your existing HTTP server.
    - When you start the Socket.IO server, it automatically serves the socket.io.js client library 
        at the /socket.io/socket.io.js endpoint.
*/
const io = new Server(server); 

//socket.io
io.on("connection", (socket)=>{
    socket.on("user-message", (message)=>{
        io.emit("Emiting user-message", message); //server sending the message to the others
    })
}); 

app.get("/", (req, res)=>{
    return res.sendFile("/public/index.html")
})

server.listen(9000, (req, res)=>{console.log("Server Listening at PORT 9000")})
```

**Frontend**

```javascript
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>CHAT</h2>
    <input type="text", id="message", placeholder="Enter Message">
    <button id="button">SEND</button>
    <div id="chat"></div>
    <script src="/socket.io/socket.io.js"></script>
    <script>
        const socket = io(); // creates the socket connection 
        const button = document.getElementById("button");
        const message = document.getElementById("message");
        const getChat = document.getElementById("chat");

        button.addEventListener("click", (e)=>{
            const value = message.value;
            /* 
                This sends the message to the server.
                Sending message to the server

                This sends "user-message" to the server.
                Use this for catching it on backend for evaluation or for enabling server to the send this message to others
            */
            socket.emit('user-message', value) 
        })

        /*
            catching the Message by the server
        */
       socket.on("Emiting user-message", (message)=>{
        const p = document.createElement("p");
        p.innerText = message;
        getChat.appendChild(p);
       })

    </script>
</body>
</html>
```

<hr>

### Streams

`Large Data ko chunks mai divide karke respond mai bhejna jisse high memory consumption na ho`. `Jaise Jaise data aata jaye vaise bhejte raho.`

Streams in Node.js are a powerful way to handle data that is too large to fit in memory all at once. They allow you to read or write data sequentially in chunks, processing it without keeping it all in memory 

```context
The problem that streams solve is that in traditional data handling methods, you have to read an entire file or dataset into memory before you can process it. This becomes impractical when dealing with very large files or continuous data streams like network communications

For example, if you have a 2GB file and try to read it all into memory at once using fs.readFile(), it will likely crash your program due to insufficient memory.
```

But with `fs.createReadStream()`, you can stream the file in smaller chunks, processing each piece as it arrives without running out of memory

There are four main types of streams in Node.js: 

1. **Readable streams** - used for reading data, like `fs.createReadStream()`
2. **Writable streams** - used for writing data, like `fs.createWriteStream()`
3. **Duplex streams** - can be read from and written to, like a TCP socket
4. **Transform streams** - Duplex streams that can modify or transform the data as it's written and read, like `zlib.createGzip()`
   - ```javascript
     fs.createReadStream("./sample.txt").pipe(zlib.createGzip().pipe(fs.createWriteStream("./sample.zip")))
     ```

All streams are instances of `EventEmitter` and emit events like `data`, `end`, `error` etc. that you can listen for. The key events are:

* `data` - emitted whenever there is data available to be read
* `end` - emitted when there is no more data to be read
* `error` - emitted when an error occurs

![0](https://static-assets.amplication.com/blog/understanding-nodejs-streams/0.png)

##### `Transfer-Encoding: chunked`

Transfer-Encoding: chunked is an HTTP header that allows a server to send a response with an unknown content length by breaking it up into smaller chunks. This is useful when the total size of the response is not known ahead of time, such as when generating dynamic content or streaming data.

```javascript
app.get("/", (req, res)=>{
    const stream = fs.createReadStream("./sample.txt", "utf-8");
    stream.on("data", (chunk) => res.write(chunk));
    stream.on("end", () => res.end());
}); 
```

<hr>

### Cluster - Scale NodeJS Apps

Node.js is inherently single-threaded, which means it runs on a single core of the CPU by default. This can limit its performance, especially when handling a large number of concurrent requests or CPU-intensive tasks. To address this limitation, Node.js provides a built-in module called the **cluster module**, which allows developers to create multiple instances of their application, effectively utilizing multi-core systems.

Clustering in Node.js refers to the technique of spawning multiple child processes (workers) that can handle requests concurrently. Each worker runs in its own thread, has its own event loop, and can manage its own memory. This allows Node.js applications to take full advantage of multi-core processors, improving performance and scalability.

**IMPORTANT**

1. **Master and Worker Processes**: When using the cluster module, there is a master process that manages the worker processes. The master process is responsible for starting worker processes and distributing incoming requests among them.
2. **Load Balancing**: The cluster module includes a built-in load balancer that distributes incoming connections to the worker processes. By default, it uses a round-robin strategy, ensuring that each worker gets an equal share of the requests. This helps prevent any single worker from becoming overwhelmed.
3. **Inter-Process Communication (IPC)**: Workers communicate with the master process using IPC. This allows the master to monitor the health of workers and restart any that crash, ensuring high availability of the application.
4. **Fault Tolerance**: If a worker crashes, the master can automatically restart it, allowing the application to continue running without downtime. This is particularly important for production applications, where reliability is crucial.

![blog.devgenius.io](https://miro.medium.com/v2/resize:fit:1400/1*VHeAcfDcC8EuFo093SeZlA.png)

![Utilizing Node.js Cluster for Maximum CPU Efficiency | Hupp ...](https://i0.wp.com/hupp.tech/wp-content/uploads/2023/08/Node.js_cluster.jpg?fit=950%252C550&amp;ssl=1)

```javascript
const cluster = require("cluster");
const os = require("os");
const express = require("express");  

const totalCPUs = os.cpus().length;


if (cluster.isPrimary){
    console.log(`Primary ${process.pid} is running`);
    for(let i=0; i<totalCPUs; i++){
    cluster.fork(); //creating worker clusters 
}
} else {
    const app = express();
}
```

<hr>

### Nginx [Engine-x]

NGINX is a powerful web server and uses a non-threaded, event-driven architecture. [Load Balancing, HTTP Caching and Reverse Proxy]

NGINX is a high-performance web server and reverse proxy known for its efficiency, scalability, and flexibility. Unlike traditional web servers that use a threaded or process-based architecture, NGINX employs an event-driven, asynchronous architecture to handle a large number of concurrent connections with low overhead.

##### Load Balancing

NGINX Plus, the commercial version of NGINX, includes advanced load balancing capabilities. It enables integrating monitoring tools, Kubernetes container tuning, security controls, and debugging of complex application architectures .NGINX load balancing supports various algorithms like round-robin, least-connected, and IP hash. It also provides health checks to ensure that only healthy servers receive traffic

##### HTTP Caching

NGINX caches HTTP responses to reduce the load on the backend servers and improve response times. It supports caching of static files, dynamic content generated by FastCGI, uwsgi, SCGI, and memcached servers .NGINX uses an open file descriptor cache to efficiently serve static files. It also supports gzipping, byte ranges, chunked responses, and other filters to optimize HTTP responses

##### Reverse Proxy

NGINX can act as a reverse proxy, forwarding client requests to one or more backend servers. It accelerates reverse proxying with caching and supports load balancing and fault tolerance for backend servers

NGINX can proxy requests to FastCGI, uwsgi, SCGI, and memcached servers. It provides modular architecture with filters for tasks like gzipping, byte ranges, chunked responses, XSLT, SSI, and image transformation

* **Clusters** in Node.js are used to take advantage of multi-core systems by spawning multiple instances of the Node.js process to handle incoming requests. They operate at the application server level.

* **Reverse Proxies** sit in front of multiple backend servers (including Node.js clusters) and manage client requests. They operate at the network level, handling tasks like load balancing, SSL termination, caching, and serving static content.

![a38f9d6a-612c-474f-89e4-7dd09211ddf5](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/a38f9d6a-612c-474f-89e4-7dd09211ddf5.png)

![b928ecfb-43d2-4493-afc6-7d5dbd700adf](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/b928ecfb-43d2-4493-afc6-7d5dbd700adf.png)

![524c8820-5f58-40ec-bbf5-8cacb6dbb78e](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/524c8820-5f58-40ec-bbf5-8cacb6dbb78e.png)

![0ccec0be-bcf1-4454-b0ea-baf1a0e0b7cb](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/0ccec0be-bcf1-4454-b0ea-baf1a0e0b7cb.png)

<hr>

#### Working with NGiNX

- First create an Image and Container of nginx using docker. Inside the container find folder named `nginx` which will be inside etc folder. `ls etc/`

- Then move inside the nginx folder and find `nginx.conf` file.  This is the file we need to set up configuration for our nginx server and all server side coding. Enter into using editor like vim. To learn we can edit this file but first create a copy of this for backup or move the content of the nginx.conf to some other file. `mv nginx.conf nginx-backup.conf`. Then create nginx.conf using touch and add things to it
  ![09b68f13-963c-4c3c-8eef-d0d0a24a4c32](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/09b68f13-963c-4c3c-8eef-d0d0a24a4c32.png)

##### Understanding Configuration

![486660b0-fdb9-45ea-a70c-c656f0fa2867](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/486660b0-fdb9-45ea-a70c-c656f0fa2867.png)

* **Events Block**: This section is used to define global settings that affect the Nginx server as a whole.
* **HTTP Block**: This section contains configurations for handling HTTP traffic.
* **Server Block**: This is where you define settings for a specific server, such as:
  * **Listen Directive**: Specifies the port Nginx will listen on (port 80 in this case).
  * **Server Name**: Defines the server name (underscore `_` is a wildcard for any name).
  * **Location Block**: Defines how to process requests to a specific location (`/` in this case). Here, it returns a simple message: `"Hello from Nginx Conf File"`. 
  * reloading nginx - `nginx -s reload`  here s means signal

File Named `mime.types` contains content-type of some mostly used files. Which can be included in the confg file. 


![d134b3ca-d84d-4d64-8f18-b94e203db6de](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/d134b3ca-d84d-4d64-8f18-b94e203db6de.png)

<hr>


