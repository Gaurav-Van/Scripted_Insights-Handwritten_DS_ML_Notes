const {Server} = require("socket.io");

const express = require("express");
const app = express();
const path = require("path");

app.use(express.static(path.resolve("./public")));

const http = require("http");
const server = http.createServer(app);
/*
    - This line initializes the Socket.IO server and attaches it to your existing HTTP server.
    - When you start the Socket.IO server, it automatically serves the socket.io.js client library 
        at the /socket.io/socket.io.js endpoint.
*/
const io = new Server(server); 

//socket.io
io.on("connection", (socket)=>{
    socket.on("user-message", (message)=>{
        io.emit("Emiting user-message", message); //server sending the message to the others
    })
}); 

app.get("/", (req, res)=>{
    return res.sendFile("/public/index.html")
})

server.listen(9000, (req, res)=>{console.log("Server Listening at PORT 9000")})