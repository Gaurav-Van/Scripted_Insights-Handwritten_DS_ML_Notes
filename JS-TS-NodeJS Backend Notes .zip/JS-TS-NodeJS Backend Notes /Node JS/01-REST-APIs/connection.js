const mongoose = require("mongoose");

async function connectMongoDb(url) {
    try{
        return await mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true });
    }
    catch(err){
        console.log(`Error in Connecting to MongoDB: ${err}`);
        throw err; 
    }
}

module.exports = {
    connectMongoDb
}