const User_Model = require("../models/user");

async function handleGetAllUsers(req, res) {
    const users = await User_Model.find({});
    return res.json(users);
}

async function handleGetUserById(req, res){
    try{
        const user = await User_Model.findById(req.params.id);
        return res.json(user);
    }
    catch(err){
        return res.json({msg: "Error in Finding User", error: err});
    }
}

async function handleUpdateUserById(req, res){
    try{
        await User_Model.findByIdAndUpdate(req.params.id, {email: req.body.email})
        return res.json({msg: "Success in Updating User"});
    }
    catch(err){
        return res.json({msg: "Error in Updating User", error: err});
    }
}

async function handleDeleteUserById(req, res){
    try{
        await User_Model.findByIdAndDelete(req.params.id);
        return res.json({msg:"Success in Deleting User"});
    }
    catch(err){
        return res.json({msg:"Error in deletion", error:err});
    }
}

async function handleCreateNewUser(req, res){
    const body = req.body;
    if (
        !body ||
        !body.first_name ||
        !body.last_name ||
        !body.email ||
        !body.gender ||
        !body.job_title
    ){
        return res.status(404).json({msg: "All fields are required"});
    }

    try{
        const result = await User_Model.create({
            firstName: body.first_name,
            lastName: body.last_name,
            email: body.email,
            gender: body.gender, 
            jobTitle: body.job_title
        });

        return res.status(201).json({msg:"success", result: result});
    }
    catch(err){
        return res.json({msg: "some error", err: err});
    }
}

module.exports = {
    handleGetAllUsers,
    handleGetUserById,
    handleUpdateUserById,
    handleDeleteUserById,
    handleCreateNewUser
}