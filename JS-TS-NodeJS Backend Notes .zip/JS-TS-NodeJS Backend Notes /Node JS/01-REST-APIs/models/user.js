const mongoose = require("mongoose");

// creating schema - mongodb
const userSchema = new mongoose.Schema({
    firstName: {type: String, required: true,},
    lastName: {type: String,},
    email: {type: String, required: true, unique: true,},
    jobTitle: {type: String,},
    gender: {type: String,}
});

//creating model
const User_Model = mongoose.model("User_Data", userSchema);

module.exports = User_Model;