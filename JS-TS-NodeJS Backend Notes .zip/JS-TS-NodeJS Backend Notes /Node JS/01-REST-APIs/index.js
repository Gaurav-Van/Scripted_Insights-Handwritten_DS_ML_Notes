const express = require("express")
const PORT = 3000
const app = express()

const {connectMongoDb} = require("./connection")
const userRouter = require("./routes/user");

//connection
connectMongoDb("mongodb://127.0.0.1:27017/database_name");

//Middleware - Plugin 
app.use(express.urlencoded({extended:false}));

//user-routes 
app.use("/users", userRouter);

//listening
app.listen(PORT, ()=>{
    console.log(`Server Listening at ${PORT}`);
});

