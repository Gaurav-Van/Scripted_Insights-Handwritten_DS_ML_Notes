const express = require("express")
const router = express.Router();
const User_Model = require("../models/user");

const {handleGetAllUsers, handleGetUserById, handleUpdateUserById, handleDeleteUserById, handleCreateNewUser} = require("../controllers/user")

//GET and POST Fetching data 
router.route("/").get(handleGetAllUsers).post(handleCreateNewUser);

//Dynamic Enteries 
//patch = to change email id of the user 
router.route("/:id")
    .get(handleGetUserById)
    .patch(handleUpdateUserById)
    .delete(handleDeleteUserById)

module.exports = router;