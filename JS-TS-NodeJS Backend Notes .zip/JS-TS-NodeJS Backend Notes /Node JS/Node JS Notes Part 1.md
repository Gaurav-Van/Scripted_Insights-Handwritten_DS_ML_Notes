

# Learning NodeJS

<hr>

### Overview of NodeJS

`Node.js is a JavaScript runtime environment that allows developers to execute JavaScript code on the server-side. It is designed to be fast, scalable, and efficient for building server-side applications.` Express.js is used to create web services, and Node.js is used to run those services on the server-side.

- `Async`: Node.js supports asynchronous programming, which enables developers to write code that can handle multiple tasks simultaneously.

- `Built-in Support for HTTP and TCP Sockets`: Node.js includes built-in support for HTTP and TCP sockets, making it easy to create web servers and handle network requests

- `Express.js is a web application framework built on top of Node.js. It provides a robust set of features for building web applications`

- `Routing`: Express.js allows developers to define routes for handling HTTP requests. This simplifies the process of managing different URLs and HTTP methods

- `Middleware`: Express.js includes a middleware system that enables developers to execute functions at specific points in the request-response cycle. This helps in handling tasks such as authentication, caching, and error handling.

- `Templating`: Express.js supports templating engines like EJS, Pug, and Handlebars, which allow developers to dynamically render HTML pages based on data

##### Modules

For exporting functions or important stuffs from a file or module we use `modules.exports = {}` and to import the module or file we use `require('')`

<hr>

#### FIle Handling using fs

`fs` module is used. `const fs = require('fs');` Functions either run in sync or async mode. 

###### To create and read File in Sync mode

we use `fs.writeFileSync(file_name, data)` to write and `fs.readFileSync(file_name, encoding).` to read. Synchronous file operations block the event loop until the operation completes. They are executed one after the other in the order they are called 

###### To create and read File in Async mode

we use `fs.writeFile(file_name, data, callback_func)` to write and `fs.readFile(file_name, encoding, (err, result)=>{}` to read. Asynchronous file operations are non-blocking and allow the event loop to continue processing other requests while waiting for the file I/O to complete. **They take a callback function as the last argument which is called upon completion of the operation** 

<hr>

#### Working of Node Js

**Sync**

In synchronous programming, code executes in a specific sequence - one line after the other. Each operation waits for the previous one to complete before executing.  However, synchronous operations can block the main thread, making the application unresponsive until the operation completes.

**Async**

Asynchronous code allows the program to execute multiple operations concurrently without blocking the main thread. When an asynchronous operation is initiated, the main thread can continue executing other code while waiting for the operation to complete.  Asynchronous operations use callbacks, Promises, or async/await to handle the results of the operation.

**Promises**

Promises provide a more structured way to handle asynchronous operations compared to traditional callback-based approaches. Promises represent the eventual completion (or failure) of an asynchronous operation and its resulting value.When you use a Promise-based asynchronous file operation, such as `fs.promises.readFile()`, the operation returns a Promise object. You can then use the `.then()` and `.catch()` methods to handle the successful and failed cases, respectively.

**Async/Await**

The `await` keyword is used inside `async` functions to pause the execution of the function until a Promise is resolved. It allows you to write asynchronous code that looks and behaves more like synchronous code.

When you use `await` in front of a Promise, it suspends the execution of the `async` function until that Promise settles (is either fulfilled or rejected). Once the Promise is settled, the function resumes with the resolved value of the Promise. 

One important thing to note is that while `await` pauses the execution of the current `async` function, it does not block the entire application. Other asynchronous operations and event handlers can still run concurrently, maintaining the non-blocking nature of JavaScript's event loop

**Event Query and Priority**

In Node.js, the event loop is responsible for managing the execution of asynchronous operations. When an asynchronous operation is initiated, such as a file read, the operation is offloaded to a separate thread or the operating system, and the event loop continues to process other tasks.

When the asynchronous operation completes, it adds an event to the event queue. The event loop then checks the event queue and executes the corresponding callback function when it's its turn in the queue. This prioritization ensures that time-sensitive and high-priority tasks, like Promises and I/O callbacks, are executed as soon as possible, while lower-priority tasks like timers are executed later.

When an asynchronous file operation completes, the resulting callback is added to the I/O Callbacks queue, and the event loop will execute it when it reaches that point in the queue, ensuring that the application remains responsive and can handle multiple concurrent requests.

![pentestmag.com](https://pentestmag.com/wp-content/uploads/2022/07/2022-07-04-promises.png)

<hr>

#### Making Requests, Headers and Status Codes

REST requires that a client make a request to the server in order to retrieve or modify data on the server. A request generally consists of:

* an HTTP verb, which defines what kind of operation to perform
* a _header_, which allows the client to pass along information about the request
* a path to a resource
* an optional message body containing data

#### Header

Headers are key-value pairs that are sent along with HTTP requests and responses. They contain metadata that provides information about the request or response, such as authentication details, caching policies, and content types

There are two main types of headers:

1. **Request Headers**: These are sent by the client to the server and contain information about the request. Examples include:
   
   * `Accept`: specifies the media types that the client can accept.
   * `Authorization`: carries authentication credentials.
   * `Content-Type`: specifies the media type of the request body.
   * `User-Agent`: identifies the client application

2. **Response Headers**: These are sent by the server to the client and provide metadata about the response. Examples include:
   
   * `Content-Type`: specifies the media type of the response body.
   * `Cache-Control`: defines caching behavior.
   * `Server`: includes information about the server software and technology stack

**Making Headers**

```javascript
res.setHeader("Name of Header", "Value or Information");
```

custom headers have an notation in which "x" is added to the name of the header. `x-name-of-the-header`

**Working of express.urlencoded**

When a client sends a request to a server, it includes HTTP headers that provide important information about the request. One such header is the `Content-Type` header, which indicates the media type of the resource being sent to the server. For `express.urlencoded`, this is typically `application/x-www-form-urlencoded`.

```javascript
const express = require('express');
const app = express();

app.use(express.urlencoded({ extended: true }));
```

The `extended` option allows you to choose between the `querystring` library (when `false`) and the `qs` library (when `true`) for parsing the URL-encoded data. The `qs` library supports nested objects, while `querystring` does not.

When a request is received, Express checks the `Content-Type` header. If the header matches `application/x-www-form-urlencoded`, the middleware is invoked.

The `express.urlencoded` middleware reads the request body, which is URL-encoded data, and parses it into a JavaScript object.

###### HTTP Status Codes

1. Informational Responses (100-199)

2. Successful responses (200-299)

3. Redirection messages (300-399)

4. Client error responses (400-499)

5. Server error responses (500-599)

`res.status(201).json()`

<hr>

#### REST API

For changes = `Variable mai change then Data mai update`

A REST API (also called a RESTful API or RESTful web API) is an application programming interface (API) that conforms to the design principles of the _representational state transfer_ (REST) architectural style. REST APIs provide a flexible, lightweight way to integrate applications and to connect components in microservices architectures.

`note` Some APIs, such as SOAP or XML-RPC, impose a strict framework on developers. But developers can develop REST APIs using virtually any programming language and support a variety of data formats. The only requirement is that they align to the following six REST design principles, also known as _architectural constraints_.

##### How Rest APIs work

REST APIs communicate through HTTP requests to perform standard database functions like creating, reading, updating and deleting records (also known as CRUD) within a resource.

For example, a REST API would use a GET request to retrieve a record. A POST request creates a new record. A PUT request updates a record, and a DELETE request deletes one. All HTTP methods can be used in API calls. A well-designed REST API is similar to a website running in a web browser with built-in HTTP functionality.

**`IMP note` Earlier we used to have server side rendering (SSR) where we use to render the data on server and send it to client for loading. Here client is dependent on server and server gets busy overtime. Now we have client which is not dependent on server. Server sends only the data in a specific format and that data can be rendered in Client's specific format which is known as client side rendering (CSR). Reduces load on server and dependency of client on server. BUT NOTE SSR is faster than CSR.** So SSR or CSR depends on usecase.  

###### Dynamic Variables

denoted by `:`  colon. Variables which are dynamic in nature. Like `/api/users/:id` here id will be our dynamic variable which we can use accordingly. 

#### Rest API Convention

* `GET`: To Get Data

* `POST`: To Create Data

* `PUT`: To Update Data

* `DELETE`: To Delete Data

REST (Representational State Transfer) is an architectural style for building web services that enables communication between systems on the web. It is designed to provide standards between computer systems, making it easier for them to interact with each other. The web services that follows the **REST** architectural style is called **RESTful Web Services**

1. Respect http methods (get, post, patch, put, delete) - restful api

2. A hybrid server does 2 jobs:
   
   - at '/users' : render an html page (SSR), when it knows that surely a browser is the client
   
   - at '/api/users' : sends the data as json, so that a mobile app or react can handle that at the client side

#### Key Concepts

1. **Statelessness**: REST systems do not maintain any information about the state of the client. Each request from the client includes all the necessary information to fulfill that request. This means that the server does not need to keep track of any information about the client, making it scalable and reliable

2. **Client-Server Architecture**: The client and server are separate entities, and the client does not know about the server's implementation details. This allows for independent development and modification of the client and server without affecting each other

3. **Uniform Interface**: RESTful systems use a uniform interface to simplify interactions between components. This includes using HTTP verbs (GET, POST, PUT, DELETE) to define operations on resources, and URIs to identify resources

4. **Cacheability**: Responses from the server should indicate whether they can be cached or not. This helps reduce latency and improve performance by storing frequently accessed data in multiple caches along the request-response path

<hr>

#### URI

A URI (Uniform Resource Identifier) is a string that identifies a resource on the internet. It is used to locate and access resources on the web. URIs are used to identify resources and provide a way to interact with them. They are used in RESTful APIs to identify the resources that clients can access and manipulate.

Two Types of URIs which are `URL` which is a type of URI that provides the location of a resource on the internet. It includes the protocol, domain name, and path to the resource and `URN`which is a type of URI that identifies a resource by its name. It does not provide the location of the resource but rather a unique identifier for it

#### URIs in REST

In RESTful APIs, URIs are used to identify the resources that clients can access and manipulate. Each resource is identified by a unique URI that includes the scheme, authority, path, query, and fragment. The URI is used to specify the resource that the client wants to interact with, such as retrieving, creating, updating, or deleting it

#### URLs

A URL is the address of a specific resource on the internet. It provides a standardized way to locate and access content on the web. A typical URL consists of several components:

* **Protocol**: Specifies the protocol to use for accessing the resource, such as HTTP or HTTPS.
* **Domain**: Identifies the server or host where the resource is located.
* **Port**: Specifies the port number to use for the connection (optional).
* **Path**: Indicates the location of the resource on the server.
* **Query string**: Provides additional parameters or options for the resource (optional).
* **Fragment**: Specifies a fragment or section within the resource (optional).

![6ecbd046-e77b-457b-bb9f-baab6d59a6cd](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/6ecbd046-e77b-457b-bb9f-baab6d59a6cd.png)

#### URL Package

In Node.js, the built-in `url` module provides utilities for URL resolution and parsing. It allows you to work with URLs using JavaScript objects instead of raw strings.Here are some key features of the `url` package:

* **Parsing URLs**: The `url.parse()` function takes a URL string and returns an object with various components of the URL.
* **Formatting URLs**: The `url.format()` function takes a URL object and returns a formatted URL string.
* **Resolving URLs**: The `url.resolve()` function resolves a target URL relative to a base URL.
* **WHATWG URL API**: Node.js also supports the WHATWG URL API, which provides a more modern and standards-compliant way to work with URLs.

```javascript
url.parse(urlString, [parseQueryString], [slashesDenoteHost])
```

* `urlString`: The URL string that you want to parse.
* `parseQueryString` (optional): A boolean value that determines whether the query string should be parsed into an object using the `querystring` module's `parse()` function. The default value is `false`.
* `slashesDenoteHost` (optional): A boolean value that determines whether the first token after the literal string `//` and preceding the next `/` should be interpreted as the host. The default value is `false`.

<hr>

### Basic Important App Functions, Router and Middleware

###### `app.listen()`

- The `app.listen()` method is used to start a web server and listen for incoming connections on a specified host and port.
- It combines the creation of an HTTP server and binds the Express application to that server in one method call
- The method takes optional parameters like `port`, `host`, `backlog`, and a `callback` function.

###### `app.use()` `MIDDLEWARE`

- The `app.use()` function is used to mount middleware functions at a specific path.

- Middleware functions are executed in the order they are defined.

- Middleware functions have access to the `req` (request) and `res` (response) objects, and can perform tasks like authentication, logging, data processing, etc.

- If no path is specified, the middleware function will be executed for every request. Specifying a path applies the middleware to that specific route. 
  ![geeksforgeeks.org](https://media.geeksforgeeks.org/wp-content/uploads/20211007175759/MiddlewareChaining.png)

- **Middleware functions** can perform tasks such as:
  
  * Logging
  * Parsing request bodies
  * Adding response headers
  * Executing any code
  * Making changes to the request or response objects
  * Ending the request-response cycle
  * Calling the next middleware function

- **The next middleware function** is commonly denoted by a variable named `next`. If the current middleware function does not end the request-response cycle, it must call `next()` to pass control to the next middleware function.

- ```javascript
  app.use((req, res, next)=>{});
  
  app.use((req, res, next)=>{ 
      console.log("Task 1"); 
      next(); 
  });
  
  app.use((req, res, next)=>{ 
      console.log("Task 2 after Task 1"); 
      return res.json(); // returns and stop the flow 
      // next(); goes towards the next function or just routes
  });
  ```

###### `router.route()`

* `Purpose`: `router.route()` is used to define a route handler for a specific path within a router instance.
* `Syntax`: `router.route(path).verb(handler)`, where `path` is the URL path and `verb` is the HTTP method (e.g., `get`, `post`, etc.).
* `Example`: `router.route('/user').get((req, res) => { res.send('User page'); });`
* `Route`: A route is a combination of a URI (or path) and a specific HTTP method (GET, POST, PUT, DELETE, etc.) that defines a specific endpoint where a client can make a request.
* `Router`: The Express Router is a middleware that provides a way to organize your application's endpoints. It allows you to group related routes together and manage them independently.

###### `app.route()`

- The `app.route()` function in Express is used to create a route chain for a path. It provides a shortcut for specifying multiple HTTP verb handlers (GET, POST, PUT, DELETE, etc.) for a single path.

**`router` (a Modular Route Handler):**

* Created using `const router = express.Router()`.

* Acts as a mini-application within the main `app`.

* Groups related routes for specific functionalities (e.g., `/users`, `/products`).

* Defines CRUD operations specific to that route group.

* Doesn't listen for requests directly.

* Mounted onto the main `app` using `app.use(router)`.
  
  ```javascript
  app.use("/route", route_name);
  
  //example 
  app.use("/user", userRoute)
  ```
  
  So router helps in creating different routes for specific needs. Easy to maintain. Different file, code and route for users, products and all. Everything Mounted onto the app. 

<hr>

#### Some MongoDB, MVC and Server Side Rendering [frontend <-> data <-> backend]

`const mongoose = require("mongoose");` 

```javascript
mongoose.connect("mongodb://127.0.0.1:27017/database_name")
.then(()=>{console.log("MongoDB Connected")})
.catch((err)=>{console.log(`Error ${err}`)});
```

Note: working with DBs or external things always remeber the concept of promise and async - await. 

**_flow of work_**

Schema - Define the structure 

- Using the Schema build a Model 

- Using Model do CRUD Operations 
  
  ```javascript
  const userSchema = new mongoose.Schema({
      firstName: {type: String, required: true,},
      lastName: {type: String,},
      email: {type: String, required: true, unique: true,},
      jobTitle: {type: String,},
      gender: {type: String,
  }
  });
  
  //creating model
  const User_Model = mongoose.model("User_Data", userSchema);
  
  ```

Makes it easier to do CRUD operations. Instead of Doing everything, just use functions provided by the Model of the schema. Use Async and await with callback functions and wrap the entire thing in try catch to handle errors. 

```javascript
app.route("/api/users/:id")
    .get(async(req, res)=>{
        try{
            const user = await User_Model.findById(req.params.id);
            return res.json(user);
        }
        catch(err){
            return res.json({msg: "Error in Finding User", error: err});
        }
    })
    .patch(async(req, res)=>{
        try{
            await User_Model.findByIdAndUpdate(req.params.id, {email: req.body.email})
            return res.json({msg: "Success in Updating User"});
        }
        catch(err){
            return res.json({msg: "Error in Updating User", error: err});
        }
    })
    .delete(async(req, res)=>{
        try{
            await User_Model.findByIdAndDelete(req.params.id);
            return res.json({msg:"Success in Deleting User"});
        }
        catch(err){
            return res.json({msg:"Error in deletion", error:err});
        }
    })
```

```javascript
const User = require("../models/user");

async function handleUserSignup(req, res)=>{
    const {name, email, password} = req.body;
    await User.create({
        name,
        email,
        password
    });
    return res.render("home");
}
```

##### MVC - Model View Controller

`Jiss File mai code wahan sai main cheez export and main file mai import`

###### MVC Pattern Summary

**MVC (Model-View-Controller)** is a design pattern for structuring applications. It separates an application into three interconnected components:

1. **Model (Backend)**: Manages data, business logic, and rules. It interacts with the database, defines data schemas, and ensures data integrity.

2. **View (Frontend)**: Handles the presentation layer. It displays data to the user in a specific format and manages the user interface and interactions.

3. **Controller**: Acts as an intermediary between the Model and the View. It processes user input, interacts with the Model to retrieve or update data, and updates the View accordingly.

In a Node.js application using Express, the **Model** could be defined using Mongoose to manage MongoDB interactions, the **View** could use a templating engine like EJS to render HTML, and the **Controller** would handle the application logic, routing, and responses. This separation allows for organized code, easier maintenance, and independent development of each component.

![Everything you need to know about MVC architecture | by Zanfina Svirca ...](https://miro.medium.com/max/884/1*yrAnC64Mq_7DuhRQWkbUmQ.png)

```javascript
const express = require("express")
const router = express.Router();
const User_Model = require("../models/user");

const {handleGetAllUsers, handleGetUserById, handleUpdateUserById, handleDeleteUserById, handleCreateNewUser} = require("../controllers/user")

//GET and POST Fetching data 
router.route("/").get(handleGetAllUsers).post(handleCreateNewUser);

//Dynamic Enteries 
//patch = to change email id of the user 
router.route("/:id")
    .get(handleGetUserById)
    .patch(handleUpdateUserById)
    .delete(handleDeleteUserById)

module.exports = router;
```

```javascript
const User_Model = require("../models/user");

async function handleGetAllUsers(req, res) {
    const users = await User_Model.find({});
    return res.json(users);
}

async function handleGetUserById(req, res){
    try{
        const user = await User_Model.findById(req.params.id);
        return res.json(user);
    }
    catch(err){
        return res.json({msg: "Error in Finding User", error: err});
    }
}

async function handleUpdateUserById(req, res){
    try{
        await User_Model.findByIdAndUpdate(req.params.id, {email: req.body.email})
        return res.json({msg: "Success in Updating User"});
    }
    catch(err){
        return res.json({msg: "Error in Updating User", error: err});
    }
}

async function handleDeleteUserById(req, res){
    try{
        await User_Model.findByIdAndDelete(req.params.id);
        return res.json({msg:"Success in Deleting User"});
    }
    catch(err){
        return res.json({msg:"Error in deletion", error:err});
    }
}

async function handleCreateNewUser(req, res){
    const body = req.body;
    if (
        !body ||
        !body.first_name ||
        !body.last_name ||
        !body.email ||
        !body.gender ||
        !body.job_title
    ){
        return res.status(404).json({msg: "All fields are required"});
    }

    try{
        const result = await User_Model.create({
            firstName: body.first_name,
            lastName: body.last_name,
            email: body.email,
            gender: body.gender, 
            jobTitle: body.job_title
        });

        return res.status(201).json({msg:"success", result: result});
    }
    catch(err){
        return res.json({msg: "some error", err: err});
    }
}

module.exports = {
    handleGetAllUsers,
    handleGetUserById,
    handleUpdateUserById,
    handleDeleteUserById,
    handleCreateNewUser
}
```

###### Server Side Rendering

EJS (Embedded JavaScript) is a templating language that facilitates server-side rendering (SSR) within Node.js applications. `app.set("view engine", "ejs");` `app.set("views", path.resolve("./views"))` `res.render("file_name", {variable_name: variable_value, });`  sends Data to view | Data from backend is stored in `locals` | `<% %> format for EJS`

**Important:** `name` given to the text field or any field in general in frontend should be same as the variable saved in the backend. In ejs this is how it sends the data from frontend to backend for saving user info. 

```javascript
async function handleRenderHomePage(req, res){
    return await res.render("Home");
}
```

```javascript
// sending Data from Backend to frontend        
return res.render("home", {
            id: shortID
        })
```

```javascript
<div class="container">
        <h1>URL Shortener</h1>
        <form method="POST" action="/url">
            <input type="text" id="originalUrl" name="url" placeholder="Paste your long URL here" required>
            <input type="submit" value="Shorten URL">
        </form>
        <div class="shortened-url" id="shortenedUrl">
            <p>Your shortened URL:</p>
            <% if (locals.id) { %>
            <a href="http://localhost:8000/url/<%=id%>">http://localhost:8000/url/<%=id%></a>
            <% } %>
        </div>
    </div>
```

<hr>

### Authentication and Authorization

#### Stateful Authentication in Node.js

In a stateful authentication system, the server maintains the state of the user's authentication. This typically involves creating a session for the user after successful authentication and storing session data on the server. `cookies are usually used for server side rendering` and `headers are used for REST APIs` 

- The server creates a session for the user and generates a session ID which is sent to the client, usually stored in a cookie

- On subsequent requests, the client sends the session ID which the server uses to look up the user's session data to verify their identity

- The session data is stored server-side, allowing the server to revoke sessions and manage active sessions
  ![1f3bb579-a1a1-436c-9dc4-184dbc088d28](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/1f3bb579-a1a1-436c-9dc4-184dbc088d28.png)

###### npm uuid

The `uuid` package can be particularly useful for generating unique identifiers for cookies and session IDs, which are critical for tracking users and maintaining state in web applications.

**Session IDs** are unique identifiers assigned to a user's session. Using UUIDs for session IDs ensures that each session is uniquely identified, reducing the risk of collisions and improving security. It involves using a session identifier to keep track of the user’s authentication status across multiple requests.

**When a user logs in** to a session-based authentication system, a session identifier is created on the server and sent to the client as a cookie. The cookie is then included in all subsequent requests from the client to the server, allowing the server to identify the user and their authentication status. When the user logs out, the session identifier is deleted from the server and the client, effectively ending the session and logging the user out. 

**Storage and Mapping** is done in a dictionary way. The user detail fetched from database is connected with the generated session id in an dictionary way. Like maps or hashmaps 

```javascript
const sessionId = uuidv4();
----
const sessionIdToUserMap = new Map(); //maintaining state

function setUser(id, user) {
  sessionIdToUserMap.set(id, user);
}

function getUser(id) {
  return sessionIdToUserMap.get(id);
}
----
setUser(sessionId, user); // Mapping 
res.cookie("uid", sessionId); // creating cookie 

```

**IMPORTANT**: in stateful,  uuid is used to generate an session ID, which is then mapped to user object and on every subsequent request it is checked if we have a user with that session id using middlewares `npm i cookie-parser`

```javascript
async function restrictToLoggedinUserOnly(req, res, next) {
    const userUid = req.cookies?.uid; // name uid was given when cookie was being created using res.cookie()
    if(!userUid){
        return res.redirect("/login");
    }

    const user = getUser(userUid);
    if(!user){
        return res.redirect("/login");w
    }

    req.user = user;
   next();
}
----------
app.use("/url", restrictToLoggedinUserOnly, urlRoute); //inline middleware
```

#### Stateless Authentication [JWT or Json Web Tokens]

Stateless authentication relies on tokens that encapsulate all necessary information about the user session within the token itself.

When a user successfully authenticates, the server generates a JWT that includes user data and is signed with a secret key. This token is then sent to the client, which stores it and includes it in subsequent requests.

- JWTs contain all the information needed for authentication, such as user roles and permissions, which allows the server to validate the token without needing to reference a central session store. This reduces server overhead and enhances scalability as the server does not need to maintain session state

- A JWT is a compact, URL-safe token composed of three parts: a header, a payload, and a signature. The header typically contains the type of token and the signing algorithm used. The payload includes the claims, which are statements about an entity (typically, the user) and additional data. The signature ensures that the token has not been altered

**IMPORTANT**: When a user logs in, the server generates a JWT, signs it, and sends it back to the client. The client then sends this token with every subsequent request. The server can validate the token and extract user information without needing to maintain a session in memory. `npm i jsonwebtoken` | **payload** refers to the part of the token that contains the claims or information about the user.

`A JWT consists of three parts`:

1. **Header**: This part typically consists of two parts: the type of the token (JWT) and the signing algorithm being used (e.g., HMAC SHA256).

2. **Payload**: This is where the claims are stored. Claims are statements about an entity (typically, the user) and additional data. The payload can include:
   
   * **Registered Claims**: Standard claims defined by the JWT specification, such as:
     
     * `sub` (subject): The unique identifier for the user.
     * `iat` (issued at): The timestamp when the token was issued.
     * `exp` (expiration): The timestamp when the token will expire.
   
   * **Public Claims**: Custom claims that can be defined by the application, such as user roles or permissions.
   
   * **Private Claims**: Claims that are agreed upon between parties and are not registered or public.

3. **Signature**: This part is used to verify that the sender of the JWT is who it claims to be and to ensure that the message wasn't changed along the way. It is **created** by taking the **encoded header**, the **encoded payload**, **a secret key**, and*signing it using the specified algorithm*.

`Entire user data or payload is stored inside the token` 

`Tokens can be changed by someone who has the signature`

```javascript
const jwt = require("jsonwebtoken");
function setUser(user){
    const payload = {
        _id: user._id,
        email: user.email,
    }
    return jwt.sign(payload, secret);
}

function getUser(token){
    if(!token){
        return null
    }
    try{
        return jwt.verify(token, secret);
    }
    catch(error){
        return null;
    }
}

```

##### Cookies

Cookies are the most common way to transmit JWT tokens from the server to the client. When a user successfully logs in, the server generates a JWT token and sends it back to the client in a Set-Cookie header

The JWT token is stored in the cookie named "token". The HttpOnly flag prevents the cookie from being accessed by client-side scripts, and the Secure flag ensures it is only sent over HTTPS connections.

- On subsequent requests, the client includes the cookie in the Cookie header. Cookies are automatically included in all requests, so the client doesn't need to manually include the token. 

- Cookie - Automatically included and sent from client. Only for browsers

##### Response Headers

Alternatively, the JWT token can be sent in the response headers. When a user logs in, the server generates a JWT token and includes it in the **Authorization header**. `The token is prefixed with "Bearer " to indicate it is an access token.` On subsequent requests, the client includes the token in the Authorization header

```javascript
// authentication user Headers
function checkForAuthentication(req, res, next) {
    const authorizationHeaderValue = req.headers["Authorization"];
    req.user = null;

    if(!authorizationHeaderValue || !authorizationHeaderValue.startsWith("Bearer")){
        return next();
    }

    const token = authorizationHeaderValue.split("Bearer")[1];
    const user = getUser(token);
    req.user = user;
    return next();
}
```

### Authorization

Authorization is the process of determining whether a user has permission to perform a specific action or access certain resources within an application. **This is often based on the user's role or permissions assigned to them after they have been authenticated.**

* In Node.js, especially when using frameworks like Express, middleware functions can be employed to check user permissions before allowing access to certain routes. This is typically done by verifying the user's role or permissions against the requested resource. `app.use("/route", middleware_function, route_package_imported). ``middleware_function can either invoke next() if all things are correct or redirect user to sone other or same page. `
* **JSON Web Tokens (JWT) are commonly used for authorization** in Node.js applications. After a user logs in, a JWT is issued, which contains encoded information about the user’s identity and roles. This token is sent with subsequent requests to verify access rights.

```javascript
function restrictTo(roles=[]){
    return function(req, res, next) {
        if(!req.user) {
            return res.redirect("/login");
        }
        if(!roles.includes(req.user.role)) {
            return res.end("UnAuthorized");
        }
        return next();
}
}
```

```javascript
app.use(checkForAuthentication); // only auth users will be moved forward. This is before all the functionalities. So next will send users to all the functions or just stop it from using any. 
app.use("/url", restrictTo(["NORMAL"]), urlRoute); // authorization. Role should be added as a field in user data model
app.use("/user", userRoute);
app.use("/", staticRoute);
```

```javascript
function setUser(user){
    const payload = {
        _id: user._id,
        email: user.email,
        role: user.role,  // for authorization. tokeb us checked using jwt.verify against the signature
    }
    return jwt.sign(payload, secret);
}
```

**Basic CRUD** is setting up routes for crud operations at a url. Export them and use them in app.use. For signup and login, creates routes for user url and send data to templates back and forth. For authentication and authorization use middlewares and inline middlewares. All combined inside MVC. 

**NOTE IMPORTANT**: Use middlewares to check the validity of the token or cookie user have and use that middleware before any route so only legit users can use those routes

***General File Structure***

```
> Models
> Views
      > Partials [Resuable components across all views] 
> Controllers
> Routes
> Services [for authentication and authorization] [tokens]

Index.js

Bootstrap via cdn
```

<hr>

### Uploading Files with NodeJS and Multer

- Multer is a node.js `middleware` for handling `multipart/form-data`, which is primarily used for uploading files.

- **Multer adds a `body` object and a `file` or `files` object to the `request` object.** 

```javascript
<form action="/upload" method="post" enctype="multipart/form-data">
  <input type="file" name="avatar" />
  <button type="submit">Upload</button>
</form>
```

###### Uploading Files on server storage or server side

```javascript
// Less Control ovwr storage
const multer = require("multer");
const upload = multer({dest: "uploads/"}); // this is a middleware

app.post("/upload", upload.single("profileImage"), (req, res) => {
  console.log(req.body);
  console.log(req.file);
  return res.redirect("/");  
})
```

##### Uploading Files on DiskStorage

```javascript
// More Control over storage 
const storage = multer.diskStorage({
    destination: function(req, file, cb){ //cb is callback function [has error, 'destination folder']
       return cb(null, '/tmp/my-uploads')
},
    filename: function(req, file, cb){
       return cb(null, `${Date.now()} - ${file.originalname}`);     
},
});

const upload = multer({ storage: storage }); 

app.post("/upload", upload.single("profileImage"), (req, res) => {
  console.log(req.body);
  console.log(req.file);
  return res.redirect("/");  
}); 
```

<hr>

### Password Secure - Salting, Hashing, pre() and MongoDB virtual functions

To effectively secure user passwords in Node.js applications using MongoDB, two key concepts are employed: **salt and hash** password techniques, and the **.pre()** middleware function in Mongoose.

**Salting** involves adding a unique, random string (the salt) to each password before it is hashed. This process ensures that even if two users have the same password, their hashed values will differ due to the unique salts.

**Hashing** is the process of converting the salted password into a fixed-length string using a cryptographic algorithm. This makes it difficult for attackers to retrieve the original password from the hash.

- In Node.js, the built-in `crypto` module can be used for salting and hashing passwords.

The `.pre()` method in Mongoose is a middleware function that runs before a specified event, such as saving a document. It allows you to perform operations or validations before the data is committed to the database. In the context of password hashing, the `.pre('save')` middleware is used to hash the password before the user is saved. 

```javascript
userSchema.pre("save", function (next) {
    const user = this;

    if (!user.isModified("password")) return;

    const salt = randomBytes(16).toString();
    const hashedPassword = createHmac("sha256", salt) // algo to create hashed using salt 
      .update(user.password)  // what to update
      .digest("hex"); // in what format

    this.salt = salt;
    this.password = hashedPassword;

    next();
});
```

In Mongoose, **virtuals** are properties that do not get stored in the MongoDB database but are computed dynamically based on the values of other fields in the document. Virtuals allow you to define properties that are calculated from other fields. 

- Virtuals can have both _getters_ and _setters_. The getter is a function that returns the computed value, while the setter can be used to set values for underlying fields based on the virtual property.

- Unlike regular schema fields, virtuals do not persist in the database. They exist only in the context of the application logic.

In Mongoose, `.static` refers to a method that is defined on the model itself, allowing you to perform operations that affect the entire collection rather than individual documents. This is useful for creating functions that can be called directly on the model, such as custom queries or aggregations.

**Important:** Checking if provided password is same as in the database. **Note:** We convert the given password into hash using the salt stored in the database of the required user. Then check the both hashed passwords 

```javascript
userSchema.static('matchPassword', function(email, password){
    const user = this.findOne({email});
    if(!user) throw new Error("User Not Found");
    const salt = user.salt;
    const hashedPassword = user.password;

    const userProvidedHash = createHmac("sha256", salt).update(password).digest("hex");
    if(hashedPassword !== userProvidedHash){
        throw new Error("Password does not match");
    }
    return {...user, password:undefined, salt:undefined}; 
})
```

<hr>

### Code Examples - Basic Flow of Routing, Rendering, Token Auth [Revision]

```javascript
mongoose.connect("mongodb://127.0.0.1:27017/BlogFix");
app.use(express.urlencoded({extended:false}));

app.set("view engine", "ejs");
app.set("views", path.resolve("./views"));
```

**Routing towards user functions and switching in between pages**

```javascript
app.use("/", staticRoute);
app.use("/user", userRoute);
```

staticRoute 

```javascript
const express = require("express");
const router = express.Router();

router.get("/", (req, res)=>{
    res.render("home", {user: req.user}); //ejs view files //sending user object to frontend in locals
})

router.get("/signin", (req, res)=>{
    res.render("signin");
})

router.get("/signup", (req, res)=>{
    res.render("signup");
})

module.exports = router;
```

userRoute 

```javascript
const express = require("express");
const router = express.Router();
const {handleSignUp, handleSignIn} = require("../controllers/user")

router.post('/signup', handleSignUp);
router.post('/signin', handleSignIn)

module.exports = router;
```

controllers for userRoute

```javascript
const User = require("../models/user");

async function handleSignUp(req, res){
    const {fullName, email, password} = req.body;
    await User.create({
        fullName,
        email,
        password
    });

    return res.redirect("/");
}

async function handleSignIn(req, res){
    try{
        const {email, password} = req.body;
        const token = await User.matchPasswordAndGenerateToken(email, password);
        return res.cookie("token", token).redirect("/");
    }
    catch(err){
        return res.render("signin", {  //sending data back to frontend in locals
            error: "Incorrect Email or Password"
        })
    }
}

module.exports = {
    handleSignUp,
    handleSignIn
}
```

Tokens 

```javascript
const JWT = require("jsonwebtoken");
const secret = "#Capy#Bara#";

function createTokenForUser(user){
    const payload = {
        _id: user.id,
        email: user.email,
        profileImageURL: user.profileImageURL,
        role: user.role
    };
    const token = JWT.sign(payload, secret);
    return token;
}

function validateToken(token){
    const payload = JWT.verify(token, secret);
    return payload;
}

module.exports = {
    createTokenForUser,
    validateToken
}
```

checking for authenticated user using cookie before accepting its requests

```javascript
const {validateToken} = require("../services/authentication");

function checkforAuthenticationCookie(cookieName){
    return (req, res, next)=>{
        const tokenCookieValue = req.cookies[cookieName];
        if(!tokenCookieValue){
            return next();
    }
    try{
        const userPayload = validateToken(ltokenCookieValue);
        req.user = userPayload;
    }
    catch(err){}
    return next; 
}
}

module.exports = checkforAuthenticationCookie;
```

snippet on how to use the locals condition 

```ejs
          <% if (locals.user) { %>
            <li class="nav-item">
              <a class="nav-link" href="#">Add Blog</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                User Name
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">LogOut</a></li>
              </ul>
            </li>
          <% } %>
```

user Model

```javascript
const mongoose = require("mongoose");
const { createHmac, randomBytes } = require("crypto");
const {createTokenForUser} = require("../services/authentication")

const userSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
      },
      salt: {
        type: String,
      },
      password: {
        type: String,
        required: true,
      },
      profileImageURL: {
        type: String,
        default: "/images/default.jpg",
      },
      role: {
        type: String,
        enum: ["USER", "ADMIN"],
        default: "USER",
      },
    },
    { timestamps: true }
  );

userSchema.pre("save", function (next) {
    const user = this;

    if (!user.isModified("password")) return;

    const salt = randomBytes(16).toString();
    const hashedPassword = createHmac("sha256", salt) // algo to create hashed using salt 
      .update(user.password)  // what to update
      .digest("hex"); // in what format

    this.salt = salt;
    this.password = hashedPassword;

    next();
});

userSchema.static('matchPasswordAndGenerateToken', async function(email, password){
    const user = await this.findOne({email});
    if(!user) throw new Error("User Not Found");
    const salt = user.salt;
    const hashedPassword = user.password;

    const userProvidedHash = createHmac("sha256", salt).update(password).digest("hex");
    if(hashedPassword !== userProvidedHash){
        throw new Error("Password does not match");
    }
    const token = createTokenForUser(user); 
    return token; 
})


const User = mongoose.model("user", userSchema);
module.exports = User;
```

  logout - clear cookie and redirect 

live data from backend to frontend - send data in backend in res.render as req object or user defined object

Some folders needs explicit explanation of being static. Express needs to know if it can treat a particulat folder or data as static or not. For this we use middleware = `app.use(express.static(path.resolve("./public")));`

need to show something on redirected route - render an template or ejs file or anything

*Referencing another model as a schema property of other model*

```javascript
const commentSchema = new mongoose.Schema({
    content: {
        type: String,
        required: true
    },
    blogId: {
        type: mongoose.Schema.Types.ObjectId,
        ref:"blog"
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "user"
    }
});
```

so here comment have model of blog and user so that we link comment to the user and blog. 

![e82b658c-e287-4dac-b29e-a1215781c68c](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/e82b658c-e287-4dac-b29e-a1215781c68c.png)

**Routing and Sending Data - Important**

Use Middlewares to allow access to authorized user. send user object to frontend and block the view for unsigned users 

![f6dd550c-d828-4864-8cd2-1a77bd823b34](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/f6dd550c-d828-4864-8cd2-1a77bd823b34.png)

![66fdf425-a811-41c1-8901-3f58bfd5b01d](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/66fdf425-a811-41c1-8901-3f58bfd5b01d.png)

*Restricting only authenticated users to have access to comment*

```ejs
    <% if (locals.user) { %>
        <div class="container mt-4">
            <h1>Comments</h1>
            <form action="/blog/comments/<%= blog.blogId %>" method="POST" enctype="multipart/form-data">
                <div class="mb-4">
                    <input type="text" name="content" class="form-control" placeholder="Enter Your Comment">
                    <button class="btn btn-primary mt-3" type="submit">Submit</button>
                </div>
            </form>
        </div>
    <% } %>
```

<hr>


