const mongoose = require("mongoose");

const urlSchema = mongoose.Schema({
    shortId: {
        type: String, 
        required: true,
        unique: true
    },
    redirectURL:{
        type: String,
        required: true,
    },
    visitFreq: {type: Number}
})

const URL_Model = mongoose.model("url", urlSchema);

module.exports = URL_Model;