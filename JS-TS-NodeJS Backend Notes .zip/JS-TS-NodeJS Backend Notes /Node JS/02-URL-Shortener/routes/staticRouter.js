const express = require("express")
const router = express.Router();
const {handleRenderHomePage, handleSignupHomePage, handleLoginHomePage} = require("../controllers/staticRouter");

router.get("/", handleRenderHomePage);
router.get("/signup", handleSignupHomePage);
router.get("/login", handleLoginHomePage);

module.exports = router;