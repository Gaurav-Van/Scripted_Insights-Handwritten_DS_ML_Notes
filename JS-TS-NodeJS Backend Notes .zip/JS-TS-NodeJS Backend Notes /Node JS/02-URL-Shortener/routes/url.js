const express = require("express")
const router = express.Router();

//Gets controller functions
const {handleGenerateNewShortURL, handleGetRedirectURL} = require("../controllers/url");
router.post("/", handleGenerateNewShortURL);
router.get("/:shortId",handleGetRedirectURL);

module.exports = router;