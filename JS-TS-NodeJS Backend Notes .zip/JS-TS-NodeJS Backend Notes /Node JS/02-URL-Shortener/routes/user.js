const express = require("express");
const router = express.Router();

const {handleUserSignup, handleUserLogIn} = require("../controllers/user");

//this function after getting user data, stores them and redirects user to Home (/). 
router.post("/", handleUserSignup);
//this function after finding a user in the DB redirects it to the Home (/).
router.post("/login", handleUserLogIn);

module.exports = router;