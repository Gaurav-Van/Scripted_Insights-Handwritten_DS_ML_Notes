async function handleRenderHomePage(req, res){
    return await res.render("Home");
}

async function handleSignupHomePage(req, res){
    return await res.render("signup");
}

async function handleLoginHomePage(req, res){
    return await res.render("login");
}

module.exports = {
    handleRenderHomePage,
    handleSignupHomePage,
    handleLoginHomePage
}