const URL_Model = require("../models/url");
const shortid = require("shortid");

async function handleGenerateNewShortURL(req, res){
    const body = req.body;
    if(!body.url)
    {
        return res.status(400).json({error: "Url required"});
    }
    try{
        const shortID = shortid();
        await URL_Model.create({
            shortId: shortID,
            redirectURL: body.url,
            visitHistory: []  
        });
    
        return res.render("home", {
            id: shortID
        })
    }
    catch(err){
        return res.json({msg: "error", error:err});
    }
}

async function handleGetRedirectURL(req, res){
    try{
        const shortId = req.params.shortId;
        const result = await URL_Model.findOneAndUpdate({shortId}, { $inc: { visitFreq: 1 } });
        res.redirect(result.redirectURL);
    }
    catch(err){
        return res.json({msg:"error", error:err});
    }
}

module.exports = {
    handleGenerateNewShortURL,
    handleGetRedirectURL
}