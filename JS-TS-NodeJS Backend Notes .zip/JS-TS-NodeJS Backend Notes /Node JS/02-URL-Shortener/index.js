const express = require("express");
const path = require("path");
const app = express();
const PORT = 8000;

//importing Different Routes
const urlRoute = require("./routes/url");
const staticRoute = require("./routes/staticRouter");
const userRoute = require("./routes/user");
const {checkForAuthentication, restrictTo} = require("./middlewares/auth");

//connecting with Mongo DB
const {connectMongoDb} = require("./connection");
const cookieParser = require("cookie-parser");
connectMongoDb("mongodb://127.0.0.1:27017/urlShort")

//setting up EJS 
app.set("view engine", "ejs");
app.set("views", path.resolve("./views"));

//Parse the Input - Middleware 
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
app.use(checkForAuthentication);

//route that handles all generating shortID and redirecting based on shortID 
app.use("/url", restrictTo(["NORMAL"]), urlRoute); //inline middleware
//route that handles all the things related to user. Signup, Login and Authentication 
app.use("/user", userRoute);
//route that handles the activity on the frontend when user lands on home page [template used: EJS]
app.use("/", staticRoute);

app.listen(PORT, (req, res)=>{
    console.log(`Server Started on PORT ${PORT}`);
})