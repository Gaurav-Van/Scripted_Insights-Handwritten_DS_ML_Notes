const {validateToken} = require("../services/authentication");

function checkforAuthenticationCookie(cookieName){
    return (req, res, next)=>{
        const tokenCookieValue = req.cookies[cookieName];
        req.user = null;
        if(!tokenCookieValue){
            return next();
    }
    try{
        const userPayload = validateToken(tokenCookieValue);
        req.user = userPayload;
        return next(); 
    }
    catch(err){
        return res.render("signin", {
            error: "Problem in Validity of Auth. Sign in again"
        });
    }
}
}

module.exports = {
    checkforAuthenticationCookie
}