const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");

const app = express();
const PORT = 8000;

app.set("view engine", "ejs");
app.set("views", path.resolve("./views"));

const userRoute = require("./routes/user");
const staticRoute = require("./routes/staticRoute");
const blogRoute = require("./routes/blog");

const {checkforAuthenticationCookie} = require("./middlewares/authentication");

mongoose.connect("mongodb://127.0.0.1:27017/BlogFix");
app.use(express.urlencoded({extended:false}));
app.use(cookieParser());
app.use(express.static(path.resolve("./public")));
app.use(checkforAuthenticationCookie("token"));

app.use("/", staticRoute);
app.use("/user", userRoute);
app.use("/blog", blogRoute);

app.listen(PORT, (req, res)=>{
    console.log(`Server started at PORT: ${PORT}`);
})



