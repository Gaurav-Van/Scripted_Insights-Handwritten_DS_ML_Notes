# HTML and CSS

--------------------

## Table of Contents

| Section                          | Subsection                                      |
|----------------------------------|-------------------------------------------------|
| Basics                           | Psuedo Classes                                  |
|                                  | CSS Box Model                                   |
|                                  | Html Entity                                     |
|                                  | CSS Specificity                                 |
|                                  | Text Element                                    |
| Images and Text Boxes            | Creating Text Boxes                             |
|                                  | CSS Properties for Images                       |
| CSS Display Property             |                                                 |
| The `<div>` Element              |                                                 |
| Layouts and Grids                | Nested Layout Technique                         |
| CSS Grids                        | Grid Container                                  |
|                                  | Grid Template Columns                           |
|                                  | Grid Template Rows                              |
|                                  | Fractional Unit (`fr`)                          |
|                                  | Gap Properties                                  |
|                                  | Grid Areas                                      |
| CSS Flexbox                      | Flex Container                                  |
|                                  | Flex Direction                                  |
|                                  | Flex Property                                   |
|                                  | Align Items                                     |
|                                  | Important Differences Between Grid and Flexbox  |
|                                  | Example Layout                                  |
| CSS Positions                    | Static                                          |
|                                  | Fixed                                           |
|                                  | Absolute                                        |
|                                  | Relative                                        |
|                                  | Wrapping Elements                               |
| Responsive Design                | Media Queries                                   |
| Semantic Elements                |                                                 |

---

## Basics

Elements can be targeted via class or the component itself. [like .nameofclass or p or body] 

**Psuedo classes** 

Extended changes on only specific actions like: hover, click, transitions and shadows.  For example `.search-icon-button:hover`` .search-tooltip` = pointing to specfic class when acting on psuedo classes

*transition takes 2 values*

*box-shadow takes 4 values*

- rgba (opacity of the color) and Hex values

**CSS Box Model** 

- **outer space** = margin and inner space of the component

- **inner space** of the component = Padding, Dynamic changes allowed

- By default browsers align by text. In order to overwrite this and align some other thing we can use align property. Like *vertical align or text align*

**Html Entity**

Special Characters. <p> by default, come with margin at the top and bottom. *Width property with text to force it to new line.*

**CSS Specificity** 

Multiple lines targetting the same prop then there is a priority which is followed 

**Text Element**

Element inside text and modify that particular text <strong></strong>, <u></u>, <span></span> = custom. They too have thier own classes

**Proper Structure of HTML**

Start with <!DOCTYPE html> which instructs the browser to use new versions of the html

```html
<html> # is a web page + nesting
  <head></head> # contains all elements that are not visible on page. Like title or style or css code
  <body></body> # contains all elements that are visible on page
</html>
```

Seperate Files for CSS and HTML codes.

- *rel = relationship [stylesheet]. href.* `<link rel="stylesheet" href="styles/buttons.css">` . Can also import different fonts from internet using link

Void Elements = Don't need a closing tag. Like <link>

```css
.subscribe{
    background-color: rgb(200, 0, 0);
    color: white;
    border: none;
    border-radius: 2px;
    cursor: pointer;
    margin-right: 8px;
    margin-left: 20px;
    padding-top: 10px;
    padding-bottom: 10px;
    padding-left: 16px;
    padding-right: 16px;
    vertical-align: top;
    transition: opacity 0.15s;
}
.subscribe:hover{
    opacity: 0.75;
}
.subscribe:active{
    opacity: 0.50;
}
```

--------------

## Images and Text Boxes

### `<img>` Element

The `<img>` element is a void element used to embed images in a webpage. It has several attributes, including `src` and `class`.

#### Example:

```html
<img src="image.jpg" class="example-image" alt="Example Image">
```

### Aspect Ratio

The aspect ratio of an image is maintained if one dimension (width or height) is changed.

#### Example:

```html
<img src="image.jpg" class="example-image">
```

### CSS Properties for Images

- `object-fit`: Defines how the content of a replaced element should be resized to fit its container.
  
  - Values: `cover`, `contain`, `fill`, `none`, `scale-down`

- `object-position`: Specifies the alignment of the selected replaced element's content within the element's box.
  
  - Values: `top`, `bottom`, `left`, `right`, `center`

- Border properties: `border-style`, `border-width`, `border-color`

#### CSS Example:

```css
/* filepath: /c:/Users/gj979/OneDrive/Documents/Learning New Domain/Learning HTML CSS/Important Points/styles.css */

.example-image {
    width: 200px;
    object-fit: cover;
    object-position: top;
    border: 2px solid black;
}
```

## Creating Text Boxes

### `<input>` Element

The `<input>` element is a void element used to create interactive controls in a web form. When the `type` attribute is set to `text`, it creates a text box.

#### Example:

```html
<input type="text" class="example-input" placeholder="Search">
```

#### CSS Example:

```css
/* filepath: /c:/Users/gj979/OneDrive/Documents/Learning New Domain/Learning HTML CSS/Important Points/styles.css */

.example-input {
    display: inline-block;
    width: auto;
}
```

## CSS Display Property

### `display: inline-block`

The `display` property specifies the display behavior of an element.

- `block` element: Takes up the entire line in their container (e.g., `<p>`).
- `inline-block` element: Takes up only as much space as needed.
- `inline` element: Sits within a line of text or text elements.

#### HTML Example:

```html
<p class="block-element">This is a block element.</p>
<span class="inline-block-element">This is an inline-block element.</span>
<span class="inline-element">This is an inline element.</span>
```

#### CSS Example:

```css
/* filepath: /c:/Users/gj979/OneDrive/Documents/Learning New Domain/Learning HTML CSS/Important Points/styles.css */

.block-element {
    display: block;
}

.inline-block-element {
    display: inline-block;
}

.inline-element {
    display: inline;
}
```

## `<div>` Element

### `<div>` Element

The `<div>` element is a **block-level container** used to group other elements. It is often used for styling purposes.

#### Example:

```html
<div class="example-div">
    This div takes up the full width of its container.
</div>
```

### Default Width

By default, a `<div>` element has a width of 100%.

#### CSS Example:

```css
/* filepath: /c:/Users/gj979/OneDrive/Documents/Learning New Domain/Learning HTML CSS/Important Points/styles.css */

.example-div {
    width: 100%;
    background-color: lightgrey;
}
```

-------- 

## Layouts and Grids

### Nested Layout Technique

#### Types of Layouts

1. Vertical Layouts
2. Horizontal Layouts
3. Hybrid Structure

#### Key Points

- A `div` or a container can be used for creating layouts.
- For hybrid structures, make changes inside the `div` or container element.
- Nested `div` operations are common.

#### Important Notes

- By default, a `div` has a width of 100%.
- Vertical Layouts: Use `div` with `display: block`.
- Horizontal Layouts: Use `div` with `display: inline-block` for side-by-side elements.
- The width of any element inside a container is 100% by default. This can be adjusted as needed.

#### Example

##### HTML and CSS

```html
<div class="vertical-layout-1-thumbnail">
    <img class="thumbnail" src="thumbnails/thumbnail-1.webp" alt="Thumbnail">
</div>

<div class="vertical-layout-2-video-content">

    <div class="horizontal-layout-1-channel-picture">
        <img class="profile-picture" src="channel_pictures/channel-1.jpeg" alt="Channel Picture">
    </div>

    <div class="horizontal-layout-2-video-info">
        <p class="video-title">
            Talking Tech and AI with Google CEO Sundar Pichai!
        </p>

        <p class="video-author">
            Marques Brownlee
        </p>

        <p class="video-stats">
            3.4M views &#183; 6 Months ago
        </p>
    </div>

</div>
```

</div>

```css
/* filepath: /c:/Users/gj979/OneDrive/Documents/Learning New Domain/Learning HTML CSS/Important Points/styles.css */

.video-preview {
    width: 100%;
    display: block;
}

.vertical-layout-1-thumbnail {
    width: 100%;
    display: block;
}

.vertical-layout-2-video-content {
    width: 100%;
    display: block;
}

.horizontal-layout-1-channel-picture {
    display: inline-block;
    width: 20%;
    vertical-align: top;
}

.horizontal-layout-2-video-info {
    display: inline-block;
    width: 75%;
    vertical-align: top;
}

.thumbnail, .profile-picture {
    width: 100%;
}

.video-title, .video-author, .video-stats {
    margin: 0;
}
```

-----------------

## CSS Grids

CSS Grids provide a powerful way to create flexible and complex layouts. They allow you to define both rows and columns, making it easy to create structured and responsive designs.

### Grid Container

The element on which `display: grid` is applied. It becomes a grid container and its children become grid items.

#### Example

```css
.grid-container 
{ 
   display: grid;
}
```

### Grid Template Columns

Defines the columns of the grid with a space-separated list of values. Each value can be a length, a percentage, or the `fr` unit.

```css
.grid-container {
    display: grid;
    grid-template-columns: 100px 200px; /* Two columns: 100px and 200px wide */
}
```

### Grid Template Rows

Defines the rows of the grid with a space-separated list of values.

```css
.grid-container {
    display: grid;
    grid-template-rows: 100px 200px; /* Two rows: 100px and 200px high */
}
```

### Fractional Unit (`fr`)

The `fr` unit represents a fraction of the available space in the grid container. It is useful for creating flexible layouts.

```css
.grid-container {
    display: grid;
    grid-template-columns: 1fr 2fr; /* Two columns: first takes 1 part, second takes 2 parts of the remaining space */
}
```

### Gap Properties

* `column-gap`: Specifies the gap between columns.
* `row-gap`: Specifies the gap between rows.
* `gap`: A shorthand for setting both `row-gap` and `column-gap`.

```css
.grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    column-gap: 10px; /* 10px gap between columns */
    row-gap: 20px; /* 20px gap between rows */
}
```

### Grid Areas

You can define named grid areas and place items into these areas.

```html
<div class="grid-container">
    <div class="header">Header</div>
    <div class="sidebar">Sidebar</div>
    <div class="main">Main Content</div>
    <div class="footer">Footer</div>
</div>
```

```css
.grid-container {
    display: grid;
    grid-template-areas:
        "header header"
        "sidebar main"
        "footer footer";
    grid-template-columns: 1fr 3fr;
    grid-template-rows: auto;
    gap: 10px;
}
.header {
    grid-area: header;
    background-color: lightblue;
}
.sidebar {
    grid-area: sidebar;
    background-color: lightgreen;
}
.main {
    grid-area: main;
    background-color: lightcoral;
}
.footer {
    grid-area: footer;
    background-color: lightgoldenrodyellow;
}
```

* The `grid-template-columns` and `grid-template-rows` properties define the structure of the grid.
* The `fr` unit is useful for creating flexible layouts that adapt to the available space.
* The `gap` properties help control the spacing between grid items.
* Named grid areas make it easier to manage complex layouts.

#### `auto`

The `auto` keyword in CSS Grid is used to automatically size rows or columns based on the content within the grid items. It allows the grid to adjust the size of the rows or columns to fit the content without specifying a fixed size.

```html
<div class="grid-container">
    <div class="grid-item">Item 1</div>
    <div class="grid-item">Item 2 with more content</div>
    <div class="grid-item">Item 3</div>
    <div class="grid-item">Item 4</div>
</div>
```

```css
.grid-container {
    display: grid;
    grid-template-columns: auto auto; /* Two columns that adjust to the content size */
    gap: 10px; /* Gap between grid items */
}
.grid-item {
    background-color: lightgrey;
    padding: 20px;
    text-align: center;
}
```

* `auto` can be used in both `grid-template-columns` and `grid-template-rows`.
* It is useful for creating flexible layouts where the size of the content is not known in advance.
* When combined with other units like `fr`, `px`, or `%`, `auto` can help create dynamic and responsive grid layouts.

----------------------

## CSS Flexbox

Flexbox is a layout model that allows you to design complex layouts with ease. It is similar to CSS Grid but offers more flexibility in arranging elements.

### Flex Container

The element on which `display: flex` is applied. It becomes a flex container and its children become flex items.

##### Example:

```css
.flex-container {
    display: flex;
}
```

### Flex Direction

Defines the direction in which the flex items are placed in the flex container.

* `row`: Horizontal layout (default)
* `row-reverse`: Horizontal layout in reverse order
* `column`: Vertical layout
* `column-reverse`: Vertical layout in reverse order

```css
.flex-container {
    display: flex;
    flex-direction: row; /* Horizontal layout */
}
```

### Flex Property

The `flex` property is a shorthand for `flex-grow`, `flex-shrink`, and `flex-basis`. It defines how a flex item will grow or shrink to fit the space available.

* `flex: 1;` is similar to `1fr` in CSS Grid.

```css
.flex-item {
    flex: 1; /* Flex item will grow to fill available space */
}
```

#### Justify Content

Defines the alignment of flex items along the main axis (horizontal by default).

* `start`: Align items to the start
* `end`: Align items to the end
* `center`: Align items to the center
* `space-between`: Distribute items evenly with space between them
* `space-around`: Distribute items evenly with space around them

```css
.flex-container {
    display: flex;
    justify-content: space-between; /* Distribute items evenly with space between them */
}
```

### Align Items

Defines the alignment of flex items along the cross axis (vertical by default).

* `stretch`: Stretch items to fill the container (default)
* `start`: Align items to the start
* `end`: Align items to the end
* `center`: Align items to the center

```css
.flex-container {
    display: flex;
    align-items: center; /* Align items to the center vertically */
}
```

Important Differences Between Grid and Flexbox
----------------------------------------------

* **Grid**: More rigid. Sizes of internal containers are usually defined while styling the outer container. Changing the order of internal containers affects the display and their sizes.
* **Flexbox**: More flexible. Separation is defined in the outer container, and size is defined while styling the internal container. Changing the order does not affect the display.

### Max-Width

Defines the maximum width an element can grow to.

```css
.flex-item {
    max-width: 200px; /* Maximum width of 200px */
}
```

### Flex-Shrink

Defines the ability of a flex item to shrink if necessary.

```css
.flex-item {
    flex-shrink: 0; /* Do not shrink */
}
```

### Nested Flexbox - Important

<u>Flexbox does not automatically apply to internal layers of containers.</u> To implement flexbox in internal layers, you need to make those layers flex containers as well.

```css
.outer-container {
    display: flex;
}

.inner-container {
    display: flex;
}
```

### Centering Items Vertically and Horizontally - Important

To center items both vertically and horizontally within a flex container

```css
.flex-container {
    display: flex;
    justify-content: center; /* Center items horizontally */
    align-items: center; /* Center items vertically */
}
```

Example Layout
--------------

```html
<div class="flex-container">
    <div class="flex-item">Item 1</div>
    <div class="flex-item">Item 2</div>
    <div class="flex-item">Item 3</div>
</div>
```

```css
.flex-container {
    display: flex;
    flex-direction: row; /* Horizontal layout */
    justify-content: space-between; /* Distribute items evenly with space between them */
    align-items: center; /* Align items to the center vertically */
}
.flex-item {
    flex: 1; /* Flex item will grow to fill available space */
    max-width: 200px; /* Maximum width of 200px */
    flex-shrink: 0; /* Do not shrink */
    background-color: lightgrey;
    padding: 20px;
    text-align: center;
}
```

--------

## CSS Positions

CSS positioning allows you to control the layout of elements on a webpage by <u>specifying their position relative to other elements or the viewport</u>. This adds another dimension to the page, enabling you to create complex layouts and effects.

### Types of Positioning

#### 1. Static

- **Default Position**: Elements are positioned according to the normal flow of the document.
- **No special positioning**: This is the default value for the `position` property.

##### Example:

```css
.static-element { 
    position: static; /* Default value */
}
```

### 2. Fixed

* **Removed from Document Flow**: The element is positioned relative to the viewport and does not move when the page is scrolled.
* **Always Visible**: A fixed element stays at the same position regardless of scrolling.
* **No Gap**: It does not leave a gap in the page where it would normally have been located.

##### Example:

```css
.fixed-element {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: lightblue;
}
```

* **Height and Width**: Fixed elements can use `height` and `width` to stretch between opposite sides.
* **Padding Solution**: To prevent a fixed header from covering the body content, add padding to the body.

### 3. Absolute

* **Relative to Nearest Positioned Ancestor**: If no such ancestor exists, it is positioned relative to the initial containing block (viewport).
* **Removed from Document Flow**: Absolute elements can overlap other elements.
* **Inside Positioned Element**: When placed inside another positioned element, it behaves within the boundary of that element.
* **Z-Index**: Use `z-index` to control the stacking order of overlapping elements.

##### Example:

```css
.absolute-element {
    position: absolute;
    top: 50px;
    left: 50px;
    width: 200px;
    background-color: lightgreen;
}
```

### 4. Relative

* **Relative to Normal Position**: The element is positioned relative to its normal position.
* **Affects Absolute Positioning**: Absolute elements inside a relative element are positioned relative to the relative element.

##### Example:

```css
.relative-element {
    position: relative;
    top: 10px;
    left: 10px;
    background-color: lightcoral;
}
```

### Wrapping Elements

To position elements within a container, make the container `relative` and the inner elements `absolute`.

##### Example:

```html
<div class="relative-container">
    <div class="absolute-element">Absolute Element</div>
</div>
```

```css
.relative-container {
    position: relative;
    width: 300px;
    height: 200px;
    background-color: lightgrey;
}
.absolute-element {
    position: absolute;
    top: 20px;
    left: 20px;
    width: 100px;
    height: 100px;
    background-color: lightgreen;
}
```

#### Example

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>CSS Positions</title>
</head>
<body>
    <header class="fixed-header">Fixed Header</header>
    <div class="relative-container">
        <div class="absolute-element">Absolute Element</div>
    </div>
    <div class="static-element">Static Element</div>
    <div class="relative-element">Relative Element</div>
</body>
</html>
```

```css
/* filepath: /c:/Users/gj979/OneDrive/Documents/Learning New Domain/Learning HTML CSS/Important Points/styles.css */

body {
    padding-top: 50px; /* Prevent fixed header from covering content */
}
.fixed-header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: lightblue;
    padding: 10px;
    text-align: center;
}
.relative-container {
    position: relative;
    width: 300px;
    height: 200px;
    background-color: lightgrey;
    margin: 20px;
}
.absolute-element {
    position: absolute;
    top: 20px;
    left: 20px;
    width: 100px;
    height: 100px;
    background-color: lightgreen;
}
.static-element {
    position: static; /* Default value */
    background-color: lightyellow;
    padding: 10px;
    margin: 20px;
}
.relative-element {
    position: relative;
    top: 10px;
    left: 10px;
    background-color: lightcoral;
    padding: 10px;
    margin: 20px;
}
```

--------------------

Responsive Design
-----------------

Responsive design ensures that web pages look good on all devices by adapting the layout, font sizes, and other styling properties to various screen sizes and devices. This is achieved using CSS media queries

### Media Queries

Media queries are CSS rules that allow you to apply different styles based on the characteristics of the user’s device or viewport.

```css
/* CSS file: styles/responsive.css */
/* Styles for devices with a maximum width of 1000px */
@media (max-width: 1000px) {
    .video-page {
        grid-template-columns: 1fr 1fr 1fr;
    }
}
/* Styles for devices with a maximum width of 750px */
@media (max-width: 750px) {
    .video-page {
        grid-template-columns: 1fr 1fr;
    }
}
/* Styles for devices with a maximum width of 540px */
@media (max-width: 540px) {
    .video-page {
        grid-template-columns: 1fr;
    }
}
/* Styles for devices with a maximum width of 600px */
@media (max-width: 600px) {
    /* Add your styles here */
}
```

Semantic Elements
-----------------

Semantic elements provide meaning to the web page structure, making it easier for screen readers and search engines to understand the content. They replace generic `<div>` elements with more descriptive tags.

### Common Semantic Elements

* `<header>`: Represents the header section of a document or a section.
* `<nav>`: Represents a navigation section.
* `<main>`: Represents the main content of the document.
* `<section>`: Represents a section of content.
* `<article>`: Represents an independent piece of content.
* `<aside>`: Represents content related to the main content.
* `<footer>`: Represents the footer section of a document or a section.

By using semantic elements, the structure of the web page becomes clearer and more meaningful, improving accessibility and SEO.

----------


