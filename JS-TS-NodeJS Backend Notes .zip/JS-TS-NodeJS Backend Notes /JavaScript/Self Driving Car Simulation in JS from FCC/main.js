const carCanvas = document.getElementById("car-canvas");
carCanvas.height = window.innerHeight;
carCanvas.width = 200;