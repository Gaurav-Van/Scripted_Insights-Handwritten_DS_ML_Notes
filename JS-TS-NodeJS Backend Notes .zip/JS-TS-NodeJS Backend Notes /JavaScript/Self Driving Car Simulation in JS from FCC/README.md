# Self Driving Car Simulation in JavaScript

A Tutorial from Free Code Camp which was followed in order to practice JavaScript.

Videp Followed: <https://www.youtube.com/watch?v=Rs_rAxEsAvI&list=PLWKjhJtqVAbleDe3_ZA8h3AO2rXar-q2V>
