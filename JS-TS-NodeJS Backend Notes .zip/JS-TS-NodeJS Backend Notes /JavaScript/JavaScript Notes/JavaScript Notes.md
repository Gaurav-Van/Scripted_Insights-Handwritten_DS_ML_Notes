# JavaScript

---

# Table of Contents

| Section                    | Subsection                                | Description                                                           |
| -------------------------- | ----------------------------------------- | --------------------------------------------------------------------- |
| JavaScript Basics          |                                           | Basic concepts and execution flow                                     |
|                            | Left to Right Execution                   | JavaScript executes from left to right with automatic type conversion |
|                            | Template Strings                          | Using backticks for string interpolation                              |
|                            | Main Idea of JavaScript                   | Saving data, generating HTML, and using DOM                           |
| Data Attributes            |                                           | Working with data attributes on HTML elements                         |
|                            | Data Attributes on HTML Elements          | Attaching and retrieving information using `data-` attributes         |
| Modules                    |                                           | Exporting and importing variables in JavaScript modules               |
|                            | Exporting and Importing Variables         | Using `type="module"`, `export`, and `import` keywords                |
| Events and Event Listeners |                                           | Handling events in JavaScript                                         |
|                            | Events                                    | Actions or occurrences that happen in the browser                     |
|                            | Event Listeners                           | Functions that wait for an event to occur                             |
|                            | Event Bubbling and Capturing              | Propagation of events in the DOM                                      |
| Variables                  |                                           | Declaring and using variables in JavaScript                           |
|                            | var, let, and const                       | Differences between var, let, and const                               |
|                            | Triple Equals (===) vs Double Equals (==) | Strict vs loose equality comparison                                   |
| Sending and Getting Values |                                           | Interacting with the DOM and server                                   |
|                            | Sending Values                            | Using AJAX, Fetch API, or forms                                       |
|                            | Getting Values                            | Retrieving data from the server                                       |
| Objects                    |                                           | Working with objects in JavaScript                                    |
|                            | Creating Objects                          | Defining objects with key-value pairs                                 |
|                            | Accessing and Modifying Objects           | Using dot and bracket notation                                        |
| Memory in JavaScript       |                                           | Understanding memory allocation and garbage collection                |
|                            | Memory Allocation                         | Stack and heap memory                                                 |
|                            | Garbage Collection                        | Automatic memory management                                           |
| JSON and LocalStorage      |                                           | Working with JSON and LocalStorage                                    |
|                            | JSON                                      | Converting between JavaScript objects and JSON                        |
|                            | LocalStorage                              | Storing data in the browser                                           |
| Autoboxing                 |                                           | Primitive data types with object-like properties                      |
| Arrays                     |                                           | Common array methods and operations                                   |
|                            | Array Methods                             | push, pop, shift, unshift, slice, splice, concat, spread, flat        |
| DOM Manipulation           |                                           | Interacting with the Document Object Model                            |
|                            | Properties and Methods                    | Common DOM properties and methods                                     |
|                            | Creating and Manipulating Elements        | Using createElement, setAttribute, appendChild                        |
|                            | Inner Methods                             | innerHTML, innerText, value                                           |
| Important Functions        |                                           | Commonly used JavaScript functions                                    |
|                            | forEach                                   | Traversing arrays                                                     |
|                            | filter                                    | Creating new arrays with elements that pass a test                    |
|                            | map                                       | Transforming arrays                                                   |
|                            | reduce                                    | Reducing arrays to a single value                                     |
| Important Concepts         |                                           | Key JavaScript concepts                                               |
|                            | setTimeout                                | Running functions in the future                                       |
|                            | setInterval                               | Running functions repeatedly                                          |
|                            | Asynchronous vs Synchronous Code          | Differences in code execution                                         |
|                            | Arrow Functions                           | Using the arrow function syntax                                       |
|                            | addEventListener                          | Attaching event handlers                                              |
|                            | Closures                                  | Functions retaining access to their lexical scope                     |
|                            | this Keyword                              | Understanding the `this` context                                      |
|                            | IIFE                                      | Immediately Invoked Function Expressions                              |
| XML HTTP Requests          |                                           | Making HTTP requests in JavaScript                                    |
|                            | Ready States                              | Different states of an XMLHttpRequest                                 |
|                            | Example                                   | Making a GET request                                                  |
| Promises                   |                                           | Handling asynchronous operations                                      |
|                            | Creating Promises                         | Defining and using Promises                                           |
|                            | .then and .catch                          | Handling resolved and rejected Promises                               |
|                            | async/await                               | Using async and await for Promises                                    |
| Fetch API                  |                                           | Making HTTP requests with Fetch                                       |
|                            | Fetch Syntax                              | Basic syntax for Fetch API                                            |
|                            | Fetch Options                             | Customizing Fetch requests                                            |
|                            | Example                                   | Using Fetch with async/await and .then/.catch                         |
| call, apply, and bind      |                                           | Methods for function invocation and context management                |
| Prototype Nature           |                                           | Understanding JavaScript's prototype-based inheritance                |
|                            | Adding Methods to Prototypes              | Extending object prototypes                                           |
|                            | The `this` Keyword                        | Context of `this` in different scenarios                              |
|                            | The `new` Keyword                         | Creating instances with constructor functions                         |
|                            | Implementation Details                    | Prototype chain and inheritance                                       |
|                            | Classes and OOP                           | Using classes for object-oriented programming                         |

---

## JavaScript Basics

**Left to Right Execution**:

* JavaScript executes from left to right.
* Example: `'hello' + 3` results in `'hello3'` due to automatic type conversion.

**Template Strings**:

* Use backticks for string interpolation.
* Example: `` `hello ${First_Name} Jain` ``.

**Main Idea of JavaScript**:

* Save data in a data structure (object, array, etc.).
* Generate HTML using the data.
* Add the generated HTML to the web using DOM.

### Data Attributes

1. **Data Attributes on HTML Elements**:

   * Start with `data-` followed by any name.
   * Attach information to elements and retrieve it on any event.

   ```js
   <button data-product-name="Product1">Click me</button>
   <script>
     const button = document.querySelector('button');
     console.log(button.dataset.productName); // Output: Product1
   </script>
   ```

### Modules

1. **Exporting and Importing Variables**:

   * Add `type="module"` attribute to the file where import will happen.
   * Export variables using `export` keyword.
   * Import variables using `import` keyword.

   ```js
   <script type="module" src="file.js"></script>
   // file1.js
   export let variable = "value";
   // file2.js
   import { variable } from './file1.js';
   console.log(variable); // Output: value
   ```

### MVC (Model-View-Controller)

1. **MVC Pattern**:
   * **Model**: Manages data.
   * **View**: Displays data on the page.
   * **Controller**: Runs code when interacting with the page.

### External Libraries

1. **Using External Libraries**:

   * Example: Using DayJS for date manipulation.
   * Add script tag to include the library.

   ```js
   <script src="https://cdn.jsdelivr.net/npm/dayjs"></script>
   <script>
     const now = dayjs();
     console.log(now.format());
   </script>
   ```

### Events and Event Listeners

1. **Events and Event Listeners**:

   * `Events`: clicks, keydowns, etc.
   * `Event Listeners`: `onclick`, `onkeydown`, etc.
   * `event listeners`: listens to an event and act accordingly. They have a object "event" which helps us to identify which event they listened to [like enter event on onkeydown]

2. **Event Bubbling and Capturing**:

   * `Event Bubbling`: Bottom to top. Event bubbling is the process where an event starts from the target element and bubbles up to the root of the DOM tree. It allows parent elements to handle events triggered by their child elements.
   * `Event Capturing:` Top to bottom. Event capturing is the opposite of event bubbling. The event starts from the root and goes down to the target element. It allows parent elements to handle events before their child elements.

   ```js
   <div id="parent">
     <button id="child">Click me</button>
   </div>
   
   <script>
     document.getElementById('parent').addEventListener('click', () => {
       console.log('Parent clicked');
     }, true); // true for event capturing. If 3rd Parameter which is optional is true then event capturing will occur. By Default its value is False 
   
     document.getElementById('child').addEventListener('click', () => {
       console.log('Child clicked');
     });
   </script>
   ```

   ```js
   document.body.addEventListener('keydown', (event) => {
     if (event.key === 'Enter') {
       console.log('Enter key pressed');
     }
   }, false); // false for event bubbling, true for event capturing. If 3rd Parameter which is optional is false then event bubbling will occur. By Default its value is False
   ```

   ```js
   const button3 = document.getElementById("btn-3");

   button3.addEventListener("mouseover", () => {
      button3.style.backgroundColor = 'blue';
   });
   ```

3. **Event Delegation**: Allows users to append a single event listener to a parent element that add it to all of its present and future childs that matches the selector. Follows the concept of event bubbling.

   ```js
    const parent = document.querySelector("#sports");

    parent.addEventListener('click', (e) => {

      console.log(e.target.getAttribute('id') + 'is selected');

      const target = e.target;
      if(target.matches('li'))
      {
        target.style.backgroundColor = "lightgrey";
     }
    });
    ```

### Variables

* `var`: has problems or errors with scoping of variable.
  
  * Function-scoped.
  * Can be re-declared and updated.

* `let`: better version of var
  
  * Block-scoped.
  * Cannot be re-declared but can be updated.

* `const`

```js
function example() {
  var x = 1;
  if (true) {
    var x = 2; // Same variable
    console.log(x); // 2
  }
  console.log(x); // 2

  let y = 1;
  if (true) {
    let y = 2; // Different variable
    console.log(y); // 2
  }
  console.log(y); // 1
```

**Triple and Double Equals**

* **Triple**: Strict equality. No type conversion. Both value and type must be the same. Triple Equals checks the data and the data type as well. Always use triple equal for comparison
* **Double**: Loose equality. Type conversion occurs. Only values are compared.

**Send and Get values from JS**

1) **Send**: On action on elements, we can send in the value as `function argument`. You can send values to a server using AJAX, Fetch API, or forms.
2) **Get**: Using `document.getElementById()`. we can get values from JS back to front. You can get values from a server using AJAX or Fetch API.

### Objects

Instance of something. Created using `{}` in JavaScript. `Key Value Pair concept`. Useful for Grouping Similar Values. Can have different types of values. `Nesting is possible`. `Can have a function inside a object`.

```js
const person = {
  firstName: 'John',
  lastName: 'Doe',
  age: 30,
  greet: function() {
    console.log('Hello, ' + this.firstName);
  }
};

console.log(person.firstName); // John
person.greet(); // Hello, John
```

**IMPORTANT** | **Behaviour of Objects in JS**: Objects are` references`. They point or only contains reference to the actual storage of values. So if using const, it will prevent changing reference but not the values residing in that reference . Follows the concept of `copy by reference`

#### JavaScript Object Methods and Concepts

`Object.freeze()` method freezes an object, preventing new properties from being added to it, existing properties from being removed, and existing properties from being changed.

```js
const obj = { name: 'John' };
Object.freeze(obj);
obj.name = 'Doe'; // This will not change the name property
console.log(obj.name); // Output: John
```

`Object.assign()` method copies all enumerable own properties from one or more source objects to a target object. It returns the target object

```js
const target = { a: 1 };
const source1 = { b: 2 };
const source2 = { c: 3 };
const result = Object.assign(target, source1, source2);
console.log(result); // Output: { a: 1, b: 2, c: 3 }
```

**Object Destructuring**: Object destructuring allows you to extract properties from an object and assign them to variables.

```js
const person = { name: 'John', age: 30 };
const { name, age } = person;
console.log(name); // Output: John
console.log(age); // Output: 30
```

#### Spread out
In order to assign COPY and Not Reference of one object to another we can use the concept of spreading

**"..." is known as REST operator**. Implements the concept of Destructuring.
```js
arr2 = [...arr1]; //Copy
```
#### Destructuring Assignment
Spreading values of an Object.

**The destructuring concept ( [key:new_var] = object ) will extract the value from the key and assign it to the new_var**

```js
const news = {
  breaking: true,
  important: false
};
let [important: isImportantNews] = news; 
```

#### Constructor Function and `new` Keyword

A constructor function is used to create multiple instances of an object with the same properties and methods. The `new` keyword is used to create a new instance of the object.

```js
function Person(name, age) {
  this.name = name;
  this.age = age;
}

const john = new Person('John', 30);
console.log(john.name); // Output: John
console.log(john.age); // Output: 30
```

##### **IMPORTANT**

`Object.getOwnPropertyDescriptor()` method returns a property descriptor for a named property on an object.

```js
const obj = { name: 'John' };
const descriptor = Object.getOwnPropertyDescriptor(obj, 'name');
console.log(descriptor);
// Output: { value: 'John', writable: true, enumerable: true, configurable: true }
```

`Object.defineProperty()` method defines a new property directly on an object, or modifies an existing property on an object, and returns the object.

```js
const obj = {};
Object.defineProperty(obj, 'name', {
  value: 'John',
  writable: false, // Important here 
  enumerable: true,
  configurable: true
});
console.log(obj.name); // Output: John
obj.name = 'Doe'; // This will not change the name property because writable is false
console.log(obj.name); // Output: John
```

**Memory**

In JavaScript, memory management involves two main types of storage: the stack and the heap. Primitive data types such as numbers, strings, booleans, null, undefined, symbols, and bigints are stored in the stack. The stack is a simple, fast memory structure where values are stored and accessed in a last-in, first-out (LIFO) manner. When you assign a primitive value to a variable or pass it to a function, a copy of the value is made, ensuring that changes to the value do not affect the original variable.

Non-primitive data types, including objects and arrays, are stored in the heap, a larger and more complex memory structure that allows for dynamic memory allocation. These types are managed by reference, meaning that when you assign a non-primitive value to a variable or pass it to a function, a reference to the value is made rather than a copy. This means changes to the value through one reference will affect all references to that value. JavaScript's garbage collector automatically frees up memory that is no longer in use by identifying and removing objects that are no longer reachable, ensuring efficient memory usage.

----

## Built-In Objects

#### JSON

JSON (JavaScript Object Notation) is a lightweight data interchange format that is easy for humans to read and write and easy for machines to parse and generate. It is similar to JavaScript objects but with fewer features, making it more universal and suitable for API interactions.

`Similar to JS Object but with less features [like does not support inside functions] [more universal] [so use in API Working] `

**Convert JavaScript Object to JSON**

```js
const jsObject = { name: "John", age: 30 };
const jsonString = JSON.stringify(jsObject);
console.log(jsonString); // Output: '{"name":"John","age":30}'
```

**Convert JSON to JavaScript Object**

```js
const jsonString = '{"name":"John","age":30}';
const jsObject = JSON.parse(jsonString);
console.log(jsObject); // Output: { name: 'John', age: 30 }
```

### LocalStorage

LocalStorage is a web storage API that allows you to store data more permanently in the browser. Unlike variables, data stored in LocalStorage persists even after the browser is closed. However, LocalStorage only supports strings.

`If you need to store objects or arrays, you'll need to convert them to a string format, such as JSON, before storing them`

**Set Item in LocalStorage**

```js
localStorage.setItem('name', 'John');
localStorage.setItem('user', JSON.stringify({ name: 'John', age: 30 }));
```

**Get Item from LocalStorage**

```js
const name = localStorage.getItem('name');
const user = JSON.parse(localStorage.getItem('user'));
console.log(name); // Output: John
console.log(user); // Output: { name: 'John', age: 30 }
```

Autoboxing
----------

Autoboxing is the process where primitive data types are automatically wrapped in their corresponding object wrappers, allowing them to have object-like properties and methods. For example, strings are wrapped in a special object that enables them to have methods like `length` and `toUpperCase`.

## Arrays

Arrays in JavaScript are used to store multiple values in a single variable. They come with various methods to manipulate the data.

* **push**: Adds one or more elements to the end of an array.

```js
const arr = [1, 2, 3];arr.push(4);console.log(arr); // Output: [1, 2, 3, 4]
```

* **pop**: Removes the last element from an array.

* **shift**: Removes the first element from an array.

* **unshift**: Adds one or more elements to the beginning of an array.

* **slice**: Returns a shallow copy of a portion of an array into a new array.

```js
const arr = [1, 2, 3, 4];const newArr = arr.slice(1, 3);console.log(newArr); // Output: [2, 3]
```

* **splice**: Changes the contents of an array by removing or replacing existing elements and/or adding new elements.

```js
const arr = [1, 2, 3, 4];arr.splice(1, 2, 'a', 'b');console.log(arr); // Output: [1, 'a', 'b', 4]
```

* **concat**: Merges two or more arrays.

* **spread operator**: Expands an array into individual elements.

```js
const arr1 = [1, 2];const arr2 = [3, 4];const newArr = [...arr1, ...arr2];console.log(newArr); // Output: [1, 2, 3, 4]
```

* **flat**: Creates a new array with all sub-array elements concatenated into it recursively up to the specified depth.

```js
const arr = [1, [2, [3, [4]]]];
const flatArr = arr.flat(2);
console.log(flatArr); // Output: [1, 2, 3, [4]]
```

* **forEach()**: Traverses an array in a loop style. It does not return anything.

```js
array.forEach((value, index) => {
  console.log(value, index);
});
```

* **filter()**: Creates a new array with all elements that pass the test implemented by the provided function.

```js
const filteredArray = array.filter(value => value > 10);
```

* **map()**: Similar to `forEach` but returns a new array with the results of calling a provided function on every element.

```js
const mappedArray = array.map(value => value * 2);
```

* **reduce()**: Executes a reducer function on each element of the array, resulting in a single output value.

```js
const sum = array.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
```

-----------

Document Object Model (DOM)
---------------------------

### Overview

The Document Object Model (DOM) is a programming interface for web documents. It represents the structure of a webpage as a tree of objects. The `document` object represents the webpage, while the `window` object represents the browser. The `document` object is a property of the `window` object.

#### Common Properties:

* `.title`: Gets or sets the title of the document.
* `.body`: Gets the body element of the document.

#### Common Methods:

* `.remove()`: Removes the specified element from the DOM.

#### Methods to Select Elements:

* `.querySelector('element_name')`: Selects the first occurrence of the specified element.

```js
const element = document.querySelector('div');
```

* `.querySelector('.class_name')`: Selects the first element with the specified class.

```js
const element = document.querySelector('.myClass');
```

* `.querySelector('id_attribute')`: Selects the first element with the specified ID

```js
const id_element = document.querySelector('id');
```

* `.querySelectorAll('element_name' or '.class_name' or 'id_attribute')`: Selects all the occurance of element with the specified ID or element name or class name

```js
const element = document.querySelectorAll("div" or ".myClass" or "id");
```

* `.getElementById('id_attribute')`: Selects the element with the specified ID.

```js
const element = document.getElementById('myId');
const title = document.getElementById("main-heading");
```

* `.getElementByClassName('class_Name'):` Selects the number of elements in an Array form that have class name as 'class_Name'.

```js
const items = document.getElementByClassName("list-items");
```

#### Methods to Create and Manipulate Elements:

* `.createElement('element_name')`: Creates a new element.

```js
const div = document.createElement('div');
div.className = 'main';
div.id = 'mainDiv';

// .setAttribute('attr_name', 'attr_value'): Sets an attribute for the created element.

div.setAttribute('title', 'generated title');
```

* `.appendChild('created_element_name')`: Adds the created element to the document.

```js
document.body.appendChild(div);
```

#### Methods for All or Specific Elements

* `.innerHTML`: Controls all the HTML inside the given element.

```js
document.body.innerHTML = '<h1>Hello World</h1>';
```

* `.innerText`: Controls all the text inside the given element.

```js
document.querySelector('button').innerText = 'Click Me';
```

* `.value`: Represents the current value of an input element (specific to `<input>`, `<textarea>`, and `<select>`).

```js
const inputValue = document.querySelector('input').value;
```

###### Optimization

Using `.innerHTML` can traverse the entire DOM tree, which may cause performance issues. It is suggested to use `.appendChild()` and `createTextNode()` for better performance.

* You can create HTML inside JavaScript using template literals and then use `.innerHTML` to insert it into the DOM.
* You can create a group of HTML elements inside a variable using concatenation and then add them to the DOM using `.innerHTML`.
* Basic flow: Use functions on events and inside functions, use the DOM to interact with the webpage.

##### Important Concepts

`setTimeout()` allows you to run a function in the future. The function will execute once after the specified time.

```js
setTimeout(() => {
  console.log('This will run after 2 seconds');
}, 2000);
```

 `setInterval()` allows you to run a function repeatedly, with a fixed time delay between each call.

```js
setInterval(() => {
  console.log('This will run every 2 seconds');
}, 2000);
```

##### Asynchronous vs Synchronous Code

* **Asynchronous Code**: Executes without waiting for a line/task to finish before moving to the next line. It allows parallel execution but not simultaneously.
* **Synchronous Code**: Waits for one line/task to finish before moving to the next line, ensuring in-order execution.

##### Arrow Functions

Arrow functions use the `=>` syntax and do not have their own bindings to `this` or `super`. They are useful for concise function expressions. The keyword `function` is replaced with `=>` . function() {} turns to () => {}. However, it’s important to note that arrow functions behave differently from traditional functions in certain ways.

For example, they do not have their own bindings to this or super. If {} then need return [explicit return] . Implicit return - Single line statements inside function - const nam  = () => (num1 + num2) . *no mention of return required*

#### Closures

A closure is a function that retains access to its lexical scope, even when the function is executed outside that scope. If a function has access to a value, it will always have access to that value.

```js
function outer() {
  let count = 0;
  return function inner() {
    count++;
    console.log(count);
  };
}
const counter = outer();
counter(); // Output: 1
counter(); // Output: 2
```

#### Immediately Invoked Function Expressions (IIFE)

Runs as soon as it is defined. `(function () { // statements })(//parameter)` . Since any variables declared within an IIFE cannot be accessed from the outside world, it helps in maintaining data privacy and avoiding global scope pollution. `(() => {}) (parameter)`

```js
(function() {
  console.log('IIFE executed');
})();

(() => {
  console.log('Arrow IIFE executed');
})();
```

---------------------

XML HTTP Requests
-----------------

### Overview

XML HTTP Requests (XHR) are used to interact with servers. They allow you to retrieve data from a URL without having to do a full page refresh. This makes web pages more dynamic and interactive.

### Ready States

XML HTTP Requests have five ready states that indicate the status of the request:

1. **Unsent (Value: 0)**: Client has been created. `open()` not called yet.
2. **Opened (Value: 1)**: `open()` has been called.
3. **Headers Received (Value: 2)**: `send()` has been called, and headers and status are available.
4. **Loading (Value: 3)**: Downloading; `responseText` holds partial data.
5. **Done (Value: 4)**: The operation is complete.

### Example

Here is an example of making an XML HTTP Request to fetch data from an API

```js
const requestUrl = 'https://api.github.com/users/gaurav-van';
const xml = new XMLHttpRequest(); // Creating an instance of XMLHttpRequest

xml.open('GET', requestUrl); // Initializing the request

// Tracking the changing state of the request
xml.onreadystatechange = function() {
  console.log(xml.readyState); // Logging the current ready state

  if (xml.readyState === 4) { // Checking if the request is complete
    const data = JSON.parse(this.responseText); // Parsing the response text
    console.log(data.followers); // Logging the number of followers
  }
};

xml.send(); // Sending the request
```

------------

## JavaScript Promises

Introduction to Promises
------------------------

A Promise in JavaScript is an object that represents the eventual completion or failure of an asynchronous operation and its resulting value. Promises provide a way to handle asynchronous operations without blocking the rest of your code.
Event Completion and Failure

#### Event Completion (resolve)

When a Promise is fulfilled, the `resolve` function is called, and the `.then()` callback of the Promise is executed. The data or resulting value is passed from `resolve` to `.then()`.

#### Event Failure (reject)

When a Promise is rejected, the `reject` function is called, and the `.catch()` callback of the Promise is executed. The error or resulting value is passed from `reject` to `.catch()`.

#### .then Callback Chain

The `.then()` method returns a Promise, allowing you to chain additional `.then()` callbacks. Each `.then()` waits for the Promise returned by the previous `.then()` to resolve and takes its resulting value.
Handling Promises: async/await vs .then/.catch

----------------------------------------------

### async/await

**IMPORTANT**: The `async` keyword is used to declare a function as asynchronous, meaning it will return a Promise. Inside an `async` function, you can use the `await` keyword to pause the execution of the function until a Promise is resolved or rejected. If the Promise is resolved, the value is returned. If the Promise is rejected, an error is thrown. You can catch these errors using a `try/catch` block.

**Async** = Makes a function return a promise.
**await** = wait for a promise to finish before going to the next line. if it fails then we have catch block

```js
async function consumePromiseFive() {
    try {
        const response = await promiseFive;
        console.log(response);
    } catch (error) {
        console.log(error);
    }
}

consumePromiseFive();
```

### .then/.catch

When you use `.then()` and `.catch()`, you’re attaching callbacks to the Promise. The `.then()` callback is executed when the Promise is resolved, and the `.catch()` callback is executed when the Promise is rejected.

```js
const promiseFive = new Promise(function(resolve, reject) {
    setTimeout(function() {
        let error = false;
        if (!error) {
            resolve({ username: "Javascript", password: "123" });
        } else {
            reject("ERROR");
        }
    }, 1000);
});

promiseFive
.then((user_data) => {
    console.log(user_data);
    return user_data.username;
})
.then((username) => {
    console.log(username);
})
.catch((error) => {
    console.log(error);
});
```

----------------------

## JavaScript Fetch API

The Fetch API is a modern interface that allows you to make HTTP requests in JavaScript. <u>**It returns a Promise that resolves to the Response object**</u> representing the response to the request. This response object contains the status of the request and the data returned from the server.

```js
fetch(resource)
fetch(resource, options)
```

* `resource`: The URL of the resource you want to fetch.
* `options`: An optional object containing any custom settings you want to apply to the request. This can include method, headers, body, etc.

```js
const url = 'https://api.example.com/data';
const options = {
    method: 'POST', // or 'GET'
    headers: {
        'Content-Type': 'application/json',
        // 'Authorization': 'Bearer your-token' (if needed)
    },
    body: JSON.stringify({
        key1: 'value1',
        key2: 'value2'
    })
};

fetch(url, options);
```

```js
const requestUrl = 'https://api.github.com/users/gaurav-van';

async function getUserFollowers() {
    try {
        const response = await fetch(requestUrl);
        const data = await response.json();
        console.log(data.followers);
    } catch (error) {
        console.log(error);
    }
}

getUserFollowers();
```

```js
fetch(requestUrl)
.then((response) => {
    return response.json();
})
.then((data) => {
    console.log(data.followers);
})
.catch((error) => {
    console.log(error);
});
```

##### .call()

The `.call()` method invokes a function immediately, allowing you to specify the value of `this` within that function. It is useful for borrowing methods from other objects.

```js
const person = {
    fullName: function(city, country) {
        return this.firstName + " " + this.lastName + ", " + city + ", " + country;
    }
};
const person1 = {
    firstName: "John",
    lastName: "Doe"
};
console.log(person.fullName.call(person1, "Oslo", "Norway")); // Output: John Doe, Oslo, Norway
```

##### .apply()

The `.apply()` method is similar to `.call()`, but it takes an array of arguments instead of individual arguments.

```js
console.log(person.fullName.apply(person1, ["Oslo", "Norway"])); // Output: John Doe, Oslo, Norway
```

##### .bind()

The `.bind()` method creates a new function that, when called, has its `this` keyword set to the provided value. It does not invoke the function immediately.

```js
const boundFunction = person.fullName.bind(person1, "Oslo", "Norway");
console.log(boundFunction()); // Output: John Doe, Oslo, Norway
```

--------------

## Prototype Nature and Object Properties

JavaScript is a prototype-based language, meaning that objects can inherit properties and methods from other objects. This allows for a flexible and dynamic approach to object-oriented programming. One of the key features of JavaScript objects is the ability to define getters and setters, which provide controlled access to object properties.

In JavaScript, you can add methods to an object's prototype. **This allows all instances of that object to share the same method, saving memory and promoting code reuse.**

```js
function Person(firstName, lastName) {
  this.firstName = firstName;
  this.lastName = lastName;
}
Person.prototype.getFullName = function() {
  return this.firstName + ' ' + this.lastName;
};
let person1 = new Person('John', 'Doe');
console.log(person1.getFullName()); // Output: John Doe
```

#### Implementation of Prototype

<u>JavaScript's inheritance model is based on prototypes. Arrays, strings, and functions are derivatives of objects, meaning they extend the prototype of the object.</u> If a property or method is not found in an array, string, or function, JavaScript will look for it in the object's prototype.

```js
Object.prototype.customMethod = function() {
  console.log('This will affect all objects');
};
```

### Classes and OOPS

```js
class User {
  constructor(username, email, password) {
    this.username = username;
    this.email = email;
    this.password = password;
  }

  encryptPassword() {
    return `${this.password}abc`;
  }
}

const user1 = new User('john_doe', 'john@example.com', 'password123');
console.log(user1.encryptPassword()); // Output: password123abc
```

#### Creating Objects with Getters and Setters

Getters and setters are special methods that allow you to define how properties are accessed and modified. They provide a way to add logic to property access and assignment, such as validation or transformation. `get` and `set`

```js
const person = {
  _name: 'Alice', // Private property (convention)
  get name() {    // Getter
    return this._name;
  },
  set name(value) { // Setter
    if (value.length < 2) {
      console.log('Name must be at least 2 characters long');
    } else {
      this._name = value;
    }
  }
};
```

### Inheritence = Forced Prototype Behavior

```js
class User 
{
    constructor(username){
        this.username = username;
    }

    logMe(){
        console.log(`Username is ${this.username}`);
    }
}

class Teacher extends User
{
    constructor(username, email, password){
        super(username)
        this.email = email
        this.password = password
    }

    addCourse(){
        console.log(`Coursed added by teacher ${this.username}`)
    }
}

const teacher = new Teacher("ABC", "ABC@gmail.com", "124455")
teacher.logMe()
teacher.addCourse()

```

------------

### Async

![alt text](Async.jpg)

---------

### Fetch

![alt text](Fetch.png)

---------------