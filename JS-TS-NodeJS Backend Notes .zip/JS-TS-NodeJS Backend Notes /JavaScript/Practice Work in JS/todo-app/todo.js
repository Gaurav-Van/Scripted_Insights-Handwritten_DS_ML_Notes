todo_array = [];

function get_value(){
    value_todo = document.querySelector('.input').value;
    value_date = document.querySelector('.input-date').value;
    todo_array.push(
    {
        name: value_todo,
        dueDate: value_date
    }
    );
}
 
function show_value(){
    let answer = '';
    for(let i=0; i<todo_array.length; i++)
    {
       const val = todo_array[i];
       const name = val.name;
       const date = val.dueDate; 
       const list = `<div>${name}</div> 
                     <div>${date}</div>
                    <button onclick="todo_array.splice(${i}, 1); show_value();" class='button'>Delete</button>`;
       answer += list;
    };
    document.querySelector('.result').innerHTML = answer;
    document.querySelector('.input').value = '';
}