const choices = ['Rock', 'Paper', 'Scissors'];
let wins = 0;
let losses = 0;
let tie = 0; 

function get_random_number(){
    let index = Math.floor(Math.random()*3);
    return index;
}

function get_result(){
    document.getElementById("game-result").innerText = `Wins: ${wins} || Losses: ${losses} || Ties: ${tie}`;
}

function playing_game(player_choice){
    const computer_choice = choices[get_random_number()];
    
    document.getElementById("player_choice").innerText = `Your Choice: ${player_choice}`;
    document.getElementById("computer_choice").innerText = `Computer Choice: ${computer_choice}`;
    let result;

    if (player_choice === computer_choice){
        result = "TIE!";
        tie += 1;
    }
    else if ( (player_choice === "Rock") && (computer_choice === "Scissors") || (player_choice === "Paper") && (computer_choice === "Rock") || 
              (player_choice === "Scissors") && (computer_choice === "Paper")) 
    {
        result = "YOU WON";
        wins += 1;
    }

    else
    {
        result = "Computer WON .. Sharam karle thodi si"; 
        losses += 1;
    }

    document.getElementById("result").innerText = `${result}`;
    get_result();
}

