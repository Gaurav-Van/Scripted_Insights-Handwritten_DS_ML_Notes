###### `Pre-Requiste` is Basic to Intermediate Knowledge of `JavaScript`.

###### This Repo Discusses about Important Topics in TypeScript to get started.

<hr>

#### `Contents`

- [Data Types in TypeScript](#data-types-in-typescript)

- [Functions](#functions)

- [Object Types](#object-types)

- [Union Types](#union-types) 

- [Type Aliases](#type-aliases)

- [Interfaces](#interfaces)

- [Type Assertions](#type-assertions)

- [null and undefined](#null-and-undefined)

- [Enums](#enums)

- [Classes](#classes)

<hr>

## TypeScript

##### Short and Concise introduction

TypeScript is a statically typed, object-oriented programming language that builds upon JavaScript. It adds optional static typing and other features to improve the development experience.

##### Basic TypeScript Syntax

`variable_name: data_type`

```typescript
// Declare a variable
let name: string = 'Capybara';

// Declare a function
function greet(name: string): void {
    console.log(`Hello, ${name}`);
}

// Call the function
greet(name);
```

<hr>

## Data Types in TypeScript

Here we will talk about the most Important Data Types. 

#### `Number`

The `number` type in TypeScript is used to represent a numeric value. It can be either an integer or a floating-point number. Here are some key points about the `number` type:

1. **Usage**: The `number` type is used to specify that a variable should hold a numeric value.

2. **Purpose**: It ensures that the variable can only hold a numeric value, preventing the assignment of non-numeric values.

```typescript
let age: number = 35; 
let salary: number = 2300;
```

#### `Any`

The `any` type is used when a variable's type is unknown or when the variable's type hasn't yet been defined. It allows you to opt-in and opt-out of type checking during compilation, making it useful for converting existing JavaScript to TypeScript. 

```typescript
let obj: any = { x: 0 };
// None of the following lines of code will throw compiler errors.
// Using `any` disables all further type checking, and it is assumed
// you know the environment better than TypeScript.
obj.foo();
obj();
obj.bar = 100;
obj = "hello";
const n: number = obj;
```

#### `Unknown`

We may need to describe the type of variables that we do not know when we are writing an application. These values may come from dynamic content – e.g. from the user – or we may want to intentionally accept all values in our API.

```typescript
declare const maybe: unknown;

if (maybe === true) {
  // TypeScript knows that maybe is a boolean now
  const aBoolean: boolean = maybe;
  // So, it cannot be a string
  const aString: string = maybe; // Type 'boolean' is not assignable to type 'string'.
}

if (typeof maybe === "string") {
  // TypeScript knows that maybe is a string
  const aString: string = maybe;
  // So, it cannot be a boolean
  const aBoolean: boolean = maybe; // Type 'string' is not assignable to type 'boolean'.
}
```

#### `Never`

The `never` type represents the type of values that never occur. For instance, `never` is the return type for a function expression or an arrow function expression that always throws an exception or one that never returns. Variables also acquire the type `never` when narrowed by any type guards that can never be true.

```typescript
// Function returning never must not have a reachable end point
function error(message: string): never {
  throw new Error(message);
}

let x: never = true; // Error: Type 'boolean' is not assignable to type 'never'.
```

#### `Void`

* **Usage**: The `void` type is used to represent a function that does not return a value.
* **Purpose**: It is different from JavaScript, where `void` is used to represent the absence of a value. In TypeScript, `void` is used to specify that a function does not return a value.

#### `Array`

TypeScript, like JavaScript, allows you to work with arrays of values. Array types can be written in one of two ways. In the first, you use the type of the elements followed by `[]` to denote an array of that element type:

```typescript
let list: number[] = [1, 2, 3];
let list: Array<number> = [1, 2, 3];
```

#### `Tuple`

**Tuple types allow you to express an array with a fixed number of elements whose types are known, but need not be the same.** It is like Arrays with restrictions 

```typescript
// Declare a tuple type
let x: [string, number];
// Initialize it
x = ["hello", 10]; // OK
// Initialize it incorrectly
x = [10, "hello"]; // Error
```

<hr>

## Functions

TypeScript allows you to specify the types of both the input and output values of functions. You can also add return type annotations. Return type annotations appear after the parameter list

```typescript
function Basic_op(x:number, y:number): number {
    return x+y;
}

const a:number = Basic_op(10, 20);
console.log(a)
```

##### Functions which return Promises

```typescript
async function getFavoriteNumber(): Promise<number> {
  return 26;
}
```

##### Anonymous Functions

Anonymous functions are a little bit different from function declarations. When a function appears in a place where TypeScript can determine how it’s going to be called, the parameters of that function are automatically given types.

```typescript
const names = ["Alice", "Bob", "Eve"];

names.forEach((s:string):void =>  {
  console.log(s.toUpperCase());
});

// Contextual typing for function - parameter s inferred to have type string 
names.forEach((s) => {
  console.log(s.toLowerCase())
})
```

<hr>

## Object Types

This refers to any JavaScript value with properties, which is almost all of them! To define an object type, we simply list its properties and their types.

```typescript
// The parameter's type annotation is an object type
function printCoord(pt: { x: number; y: number }) {
  console.log("The coordinate's x value is " + pt.x);
  console.log("The coordinate's y value is " + pt.y);
}
printCoord({ x: 3, y: 7 });
```

##### Optional Properties

Object types can also specify that some or all of their properties are _optional_. To do this, add a `?` after the property name. 

```typescript
function printName(obj: { first: string; last?: string }) {
  // ...
}
// Both OK
printName({ first: "Bob" });
printName({ first: "Alice", last: "Alisson" });
```

##### Readonly Properties

In TypeScript, the `readonly` keyword is used to mark a property or a parameter as immutable. When a property or a parameter is marked as `readonly`, it means that the value of that property or parameter cannot be changed after it has been assigned

```typescript
interface Person {
  readonly name: string;
  age: number;
}

const person: Person = {
  name: 'John Doe',
  age: 30,
};

person.name = 'Jane Doe'; // Error: Cannot assign to 'name' because it is a read-only property.
```

<hr>

## Union Types

The first way to combine types you might see is a _union_ type. A union type is a type formed from two or more other types, representing values that may be _any one_ of those types. We refer to each of these types as the union’s _members_.

```typescript
function printID(Id: number | string):void{
  console.log(`Id is ${Id}`);
};

printID(5);
printID("5");
```

Unions can help in defining an array with elements of different data types

```typescript
const data: (string | number | boolean)[] = [1, "2", 3, false]
```

##### Working with Union Types

`TypeScript will only allow an operation if it is valid for _every_ member of the union`

```typescript
function printId(id: number | string) {
  console.log(id.toUpperCase()); // ERROR

    // Property 'toUpperCase' does not exist on type 'string | number'.
    // Property 'toUpperCase' does not exist on type 'number'.
}
```

**Solution**: _narrow_ the union with code, the same as you would in JavaScript without type annotations. _Narrowing_ occurs when TypeScript can deduce a more specific type for a value based on the structure of the code.

```typescript
function printId(id: number | string) {
  if (typeof id === "string") {
    // In this branch, id is of type 'string'
    console.log(id.toUpperCase());
  } else {
    // Here, id is of type 'number'
    console.log(id);
  }
}
```

**Note**: Sometimes you’ll have a union where all the members have something in common. For example, both arrays and strings have a `slice` method

```typescript
// Return type is inferred as number[] | string
function getFirstThree(x: number[] | string) {
  return x.slice(0, 3);
}
```

<hr>

## Type Aliases

It’s common to want to use the same type more than once and refer to it by a single name.  A _type alias_ is exactly that -  a **name** for **any** type.

```typescript
type Point_Coordinates = {
  x: number,
  y: number
}

function printcoord(pt: Point_Coordinates):void{
  console.log(`X coor is ${pt.x} and Y coor is ${pt.y}`);
};

printcoord({x: 10, y: 20});
```

```typescript
function return_corrected_coord(pt: Point_Coordinates): Point_Coordinates{
  return {x: pt.x+5, y: pt.y+10};
}

let corrected_coord = return_corrected_coord({x:10, y:20});
console.log(`Corrected_coord are: ${corrected_coord.x} and ${corrected_coord.y}`);
```

You can actually use a type alias to give a name to any type at all, not just an object type. For example, a type alias can name a union type:

```typescript
type ID = number | string;
```

## Interfaces

An _interface declaration_ is another way to name an object type

```typescript
interface Point {
  x: number;
  y: number;
}

function printCoord(pt: Point) {
  console.log("The coordinate's x value is " + pt.x);
  console.log("The coordinate's y value is " + pt.y);
}

printCoord({ x: 100, y: 100 });
```

##### DIfferences between Type Aliases and Interfaces

Type aliases and interfaces are very similar, and in many cases you can choose between them freely. Almost all features of an `interface` are available in `type`. 

`the key distinction is that a type cannot be re-opened to add new properties vs an interface which is always extendable.`

![c081c85a-da9b-41b1-8fb1-23a8c9ae1c41](file:///C:/Users/gj979/OneDrive/Pictures/Typedown/c081c85a-da9b-41b1-8fb1-23a8c9ae1c41.png)

<hr>

## Type Assertions

Sometimes you will have information about the type of a value that TypeScript can’t know about. In this situation, you can use a _type assertion_ to specify a more specific type

```typescript
const myCanvas = document.getElementById("main_canvas") as HTMLCanvasElement;
```

**Note**: TypeScript only allows type assertions which convert to a _more specific_ or _less specific_ version of a type. This rule prevents “impossible” coercions

```typescript
const x = "hello" as number;
// Conversion of type 'string' to type 'number' may be a mistake because neither type sufficiently overlaps with the other. If this was intentional, convert the expression to 'unknown' first.
```

<hr>

## null and undefined

TypeScript has two corresponding _types_ by the same names. How these types behave depends on whether you have the [`strictNullChecks`](https://www.typescriptlang.org/tsconfig#strictNullChecks) option on.

##### `strictNullChecks` off

With [`strictNullChecks`](https://www.typescriptlang.org/tsconfig#strictNullChecks) _off_, values that might be `null` or `undefined` can still be accessed normally, and the values `null` and `undefined` can be assigned to a property of any type. The lack of checking for these values tends to be a major source of bugs; we always recommend people turn [`strictNullChecks`](https://www.typescriptlang.org/tsconfig#strictNullChecks) on if it’s practical to do so in their codebase.

##### `strictNullChecks` on

With [`strictNullChecks`](https://www.typescriptlang.org/tsconfig#strictNullChecks) _on_, when a value is `null` or `undefined`, you will need to test for those values before using methods or properties on that value. Just like checking for `undefined` before using an optional property, we can use _narrowing_ to check for values that might be `null`

#### **Non-null Assertion Operator** (Postfix `!`)

TypeScript also has a special syntax for removing `null` and `undefined` from a type without doing any explicit checking. Writing `!` after any expression is effectively a type assertion that the value isn’t `null` or `undefined`

```typescript
function liveDangerously(x?: number | null) {
  // No error
  console.log(x!.toFixed());
}
```

<hr>

## Enums

Enums allow a developer to define a set of named constants. Using enums can make it easier to document intent, or create a set of distinct cases. TypeScript provides both numeric and string-based enums. An enum can be defined using the `enum` keyword.

#### Numeric Enums

```typescript
enum Direction {
  Up = 1,
  Down,
  Left,
  Right,
}
```

Above, we have a numeric enum where `Up` is initialized with `1`. All of the following members are auto-incremented from that point on.

```typescript
enum Direction {
  Up,
  Down,
  Left,
  Right,
}
```

In Above code snippet, we did not use initializers then in that case `Up` would have the value `0`, `Down` would have `1`, etc.

**Note:** enums without initializers either need to be first, or have to come after numeric enums initialized with numeric constants or other constant enum members.

#### String Enums

In a string enum, each member has to be constant-initialized with a string literal, or with another string enum member.

```typescript
enum Direction {
  Up = "UP",
  Down = "DOWN",
  Left = "LEFT",
  Right = "RIGHT",
}
```

#### Constant and Computed Members

Each enum member has a value associated with it which can be either _constant_ or _computed_. An enum member is considered constant if:

- It is the first member in the enum and it has no initializer, in which case it’s assigned the value `0`

- It does not have an initializer and the preceding enum member was a _numeric_ constant. In this case the value of the current enum member will be the value of the preceding enum member plus one

- The enum member is initialized with a constant enum expression

In all other cases enum member is considered computed.

```typescript
enum FileAccess {
  // constant members
  None,
  Read = 1 << 1,
  Write = 1 << 2,
  ReadWrite = Read | Write,
  // computed member
  G = "123".length,
}
```

#### Enums at Runtime

Enums are real **objects** that exist at runtime. For example

```typescript
enum E {
  X,
  Y,
  Z,
}

function f(obj: { X: number }) {
  return obj.X;
}

// Works, since 'E' has a property named 'X' which is a number.
f(E);
```

#### Enums at Compile Time

Even though Enums are real objects that exist at runtime, the `keyof` keyword works differently than you might expect for typical objects. Instead, use `keyof typeof` to get a Type that represents all Enum keys as strings

```typescript
enum LogLevel {
  ERROR,
  WARN,
  INFO,
  DEBUG,
}

/**
 * This is equivalent to:
 * type LogLevelStrings = 'ERROR' | 'WARN' | 'INFO' | 'DEBUG';
 */
type LogLevelStrings = keyof typeof LogLevel;

function printImportant(key: LogLevelStrings, message: string) {
  const num = LogLevel[key];
  if (num <= LogLevel.WARN) {
    console.log("Log level key is:", key);
    console.log("Log level value is:", num);
    console.log("Log level message is:", message);
  }
}
printImportant("ERROR", "This is a message");
```

#### `const` enums

In most cases, enums are a perfectly valid solution. However sometimes requirements are tighter. To avoid paying the cost of extra generated code and additional indirection when accessing enum values, it’s possible to use `const` enums. Const enums are defined using the `const` modifier on our enums

```typescript
const enum Enum {
  A = 1,
  B = A * 2,
}
```

Const enums can only use constant enum expressions and unlike regular enums they are completely removed during compilation. Const enum members are inlined at use sites. This is possible since const enums cannot have computed members.

<hr>

## Classes

As with other JavaScript language features, TypeScript adds type annotations and other syntax to allow you to express relationships between classes and other types.

In TypeScript, a class is a blueprint for creating objects. It defines the properties and methods that an object can have. Classes are a fundamental concept in object-oriented programming (OOP) and are used to create reusable components.

```typescript
class ClassName {
  // properties
  // constructor
  // methods
}
```

```typescript
class Person {
  private name: string;
  private age: number;

  constructor(name: string, age: number) {
    this.name = name;
    this.age = age;
  }

  greet(): void {
    console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
  }
}
```

#### `readonly` properties

In TypeScript, you can declare a property as `readonly` to ensure it cannot be changed once it is set. This is useful for properties that should not be modified after initialization.

```typescript
class Person {
    readonly name: string;

    constructor(name: string) {
        this.name = name;
    }
}

const person = new Person('John');
person.name = 'Jane'; // Error: Cannot assign to 'name' because it is a read-only property.
```

#### Constructors

Constructors are special methods in a class that are called when an object is created from the class. They are used to initialize class properties.

```typescript
class Person {
    private name: string;

    constructor(name: string) {
        this.name = name;
    }
}

const person = new Person('John');
console.log(person.name); // Output: "John"
```

###### Super Calls

Just as in JavaScript, if you have a base class, you’ll need to call `super();` in your constructor body before using any `this.` members

```typescript
class Base {
    k = 4;
  }

  class Derived extends Base {
    constructor() {
    super();
      console.log(this.k);
    }
  }
```

#### Methods

Methods are functions defined within a class that perform specific actions.

```typescript
class Person {
    private name: string;

    constructor(name: string) {
        this.name = name;
    }

    greet(): void {
        console.log(`Hello, my name is ${this.name}.`);
    }
}

const person = new Person('John');
person.greet(); // Output: "Hello, my name is John."
```

#### Getters / Setters

`Note that a field-backed get/set pair with no extra logic is very rarely useful in JavaScript. It’s fine to expose public fields if you don’t need to add additional logic during the get/set operations.`

```typescript
class Thing {
  _size = 0;

  get size(): number {
    return this._size;
  }

  set size(value: string | number | boolean) {
    let num = Number(value);

    // Don't allow NaN, Infinity, etc

    if (!Number.isFinite(num)) {
      this._size = 0;
      return;
    }

    this._size = num;
  }
}
```

TypeScript has some special inference rules for accessors:

* If `get` exists but no `set`, the property is automatically `readonly`
* If the type of the setter parameter is not specified, it is inferred from the return type of the getter

#### Member Visibility

`Public` is default visibility of class memebers. A public member can be accessed anywhere

`Protected` members are only visible to subclasses of the class they're declared in. 

`Private` is like protected, but doesn't allow access to the member even from subclasses. 

#### Interfaces in Classes

In TypeScript, you can use an interface to define the structure that a class should follow. This is done using the `implements` keyword. When a class implements an interface, it must provide the implementation for all the properties and methods defined in the interface.

The class is not required to follow the exact order of the members (properties and methods) as defined in the interface. However, the class must include all the members defined in the interface, with the same names and types.

Additionally, the class can have additional members (properties and methods) that are not defined in the interface.

```typescript
  interface TakePhoto {
    cameramode: string
    filter: string
    burst: number
  }

  interface Story {
    createStory(): void
  }

  class YouTube implements TakePhoto, Story{
    constructor(public cameramode: string, public filter: string, public burst: number){
    }
    createStory(): void {
    }
  }
```

#### Abstract Classes

Abstract classes in TypeScript are a powerful feature that allow developers to define a common structure and behavior for related classes, without providing a complete implementation.  `Abstract classes are base classes that cannot be instantiated directly. They serve as a blueprint or template for other classes to inherit from.`  

**`Purpose`**: The purpose of an abstract class is to provide a common set of properties and methods that can be shared among related classes, while allowing the subclasses to implement their own specific logic.

```typescript
  abstract class Animal {
    name: string;

    constructor(name: string) {
        this.name = name;
    }

    abstract makeSound(): void;

    move(distance: number): void {
        console.log(`${this.name} moved ${distance} meters`);
    }
  }

  class Dog extends Animal {
    constructor(name: string){
        super(name);
    }

    makeSound(): void {
        console.log("Woof")  //custom implementation
    }
  }

  const dog = new Dog("Buddy");
  dog.makeSound();
  dog.move(10);
```

###### Abstract Methods

Abstract classes can also contain abstract methods, which are methods without an implementation. Subclasses that extend the abstract class must provide an implementation for these abstract methods. This is a way to enforce a contract that the subclasses must follow.

#### Generics

Generics are a way to create a component that can work over a variety of types rather than a single one. They allow you to define placeholder types which are then replaced when the code is executed with the actual types passed in. Generics are like a template that can be reused across the same piece of code multiple times but with the value being independent of each invocation of the function

```typescript
function getFirstElement<T>(arr: T[]): T {
  return arr[0];
}

const numberArray = [1, 2, 3, 4, 5];
const stringArray = ['apple', 'banana', 'orange'];

const firstNumber = getFirstElement<number>(numberArray);
const firstString = getFirstElement<string>(stringArray);
```

They are defined using angle brackets `<>` and a type variable, such as `<T>`, which represents the placeholder type

```typescript
function identiy<Type>(arg: Type): Type {
  return arg;
}

let output_1 = identity<string>("mystring");

let output = identity("myString");
/*Here we use type argument inference — that is, we want the compiler to set the value of Type for us automatically based on the type of the argument we pass in*/
```

`<T>` locks up the type value for the entire scope. 

```typescript
function getSearchProdcuts<T>(products: T[]): T {
    const myIndex = 3
    return products[myIndex] // returning a number as return type is T and not T[]
}
```

```typescript
// arrow notation
const getMoreSearchProducts = <T>(products: T[]): T => {} 
```

###### Using Generics with Types and Interfaces

```typescript
interface Person<T> {
  id: number;
  name: string;
  metadata: T;
}

const personOne: Person<(number | string)[]> = {
  id: 1,
  name: 'Jeff',
  metadata: ['male', 'tall', 22],
};

const personTwo: Person<{ sex: string; height: 'tall' | 'short' }> = {
  id: 2,
  name: 'Jess',
  metadata: {
    sex: 'female',
    height: 'tall',
  },
};
```

###### Using Generics with classes

A generic class has a similar shape to a generic interface. Generic classes have a generic type parameter list in angle brackets (`<>`) following the name of the class

```typescript
class GenericNumber<NumType> {
  zeroValue: NumType;
  add: (x: NumType, y: NumType) => NumType;
}

let myGenericNumber = new GenericNumber<number>();
myGenericNumber.zeroValue = 0;
myGenericNumber.add = function (x, y) {
  return x + y;
};
```

##### Generic Constraints

Generic Constraints in TypeScript allow you to specify a "minimum requirement" for the generic type parameter. This means you can restrict the types that can be used with the generic type parameter. 

```typescript
function myFunction<T extends SomeType>(param: T): ReturnType {
  // function body
}
```

Here, `T` is the generic type parameter, and `extends SomeType` is the constraint. This means that `T` must be a type that extends (is a subtype of) `SomeType`.

The `SomeType` can be an interface, a class, a union type, or any other valid type in TypeScript.

**Constraining to an Interface**

```typescript
interface HasLength {
  length: number;
}

function logLength<T extends HasLength>(arg: T): void {
  console.log(arg.length);
}

logLength([1, 2, 3]); // OK
logLength("hello"); // OK
logLength(42); // Error: number does not satisfy constraint of type HasLength
```

**Constraining using `keyof`**

```typescript
interface Person {
  name: string;
  age: number;
  city: string;
}

function getProperty<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

const person: Person = { name: "John", age: 30, city: "New York" };
const name = getProperty(person, "name"); // OK, returns a string
const age = getProperty(person, "age"); // OK, returns a number
const address = getProperty(person, "address"); // Error: "address" is not a key of Person
```

**Constraining to a Class**

```typescript
class Animal {
  name: string;
}

class Dog extends Animal {
  breed: string;
}

function createInstance<T extends Animal>(c: { new(): T }): T {
  return new c();
}

const dog = createInstance(Dog); // OK, returns a new Dog instance
const animal = createInstance(Animal); // OK, returns a new Animal instance
const notAnimal = createInstance(Object); // Error: Object is not assignable to constraint of type Animal
```

<hr>

## Type Narrowing

Type Narrowing is the process of refining or narrowing down the type of a variable using certain conditions or checks within a code block. It allows TypeScript to infer the most accurate type for a variable at a given point in the code.Without type narrowing, 

TypeScript would have to assume the most general or "widest" type for a variable, which can lead to errors or unexpected behavior. Type narrowing helps catch these issues at compile-time rather than runtime.

**Typeof Type Guards**

Using the `typeof` operator to check the type of a variable and narrow it accordingly.

```typescript
function printLength(input: string | number) {
  if (typeof input === 'string') {
    console.log(input.length); // input is narrowed to string
  } else {
    console.log(input.toFixed(2)); // input is narrowed to number
  }
}
```

**Truthiness narrowing**

Truthiness might not be a word you’ll find in the dictionary, but it’s very much something you’ll hear about in JavaScript.

In JavaScript, we can use any expression in conditionals, `&&`s, `||`s, `if` statements, Boolean negations (`!`), and more. As an example, `if` statements don’t expect their condition to always have the type `boolean`.  In JavaScript, constructs like `if` first “coerce” their conditions to `boolean`s to make sense of them, and then choose their branches depending on whether the result is `true` or `false`

```typescript
function getUsersOnlineMessage(numUsersOnline: number) {
  if (numUsersOnline) {
    return `There are ${numUsersOnline} online now!`;
  }
  return "Nobody's here. :(";
}
```

You can always coerce values to `boolean`s by running them through the `Boolean` function, or by using the shorter double-Boolean negation.

One last word on narrowing by truthiness is that Boolean negations with `!` filter out from negated branches.

```typescript
function multiplyAll(
  values: number[] | undefined,
  factor: number
): number[] | undefined {
  if (!values) {
    return values;
  } else {
    return values.map((x) => x * factor);
  }
}

```

**Equality Narrowing**

TypeScript also uses `switch` statements and equality checks like `===`, `!==`, `==`, and `!=` to narrow types. 

```typescript
function printAll(strs: string | string[] | null) {
  if (strs !== null) {
    if (typeof strs === "object") {
      for (const s of strs) {

(parameter) strs: string[]
        console.log(s);
      }
    } else if (typeof strs === "string") {
      console.log(strs);

(parameter) strs: string
    }
  }
}
```

**In Operator Narrowing**

Using the `in` operator to check if a property exists on an object, narrowing the type.

```typescript
type Fish = { swim: () => void };
type Bird = { fly: () => void };

function move(animal: Fish | Bird) {
  if ("swim" in animal) {
    return animal.swim();
  }

  return animal.fly();
}
```

**Instanceof Narrowing**

JavaScript has an operator for checking whether or not a value is an “instance” of another value. More specifically, in JavaScript `x instanceof Foo` checks whether the _prototype chain_ of `x` contains `Foo.prototype`.  `instanceof` is also a type guard, and TypeScript narrows in branches guarded by `instanceof`s.

```typescript
function logValue(x: Date | string) {
  if (x instanceof Date) {
    console.log(x.toUTCString());

  } else {
    console.log(x.toUpperCase());

  }
}
```

**Using Type Predicates**

To define a user-defined type guard, we simply need to define a function whose return type is a _type predicate_. Gives us more control on return type. 

```typescript
function isFish(pet: Fish | Bird){ 
    return (pet as Fish).swim !== undefined; // this will return boolean values
} 

function isFish(pet: Fish | Bird): pet is Fish { 
    return (pet as Fish).swim !== undefined; // will return the pet as Fish 
}
```

`pet is Fish` is our type predicate in this example. A predicate takes the form `parameterName is Type`, where `parameterName` must be the name of a parameter from the current function signature.

Any time `isFish` is called with some variable, TypeScript will _narrow_ that variable to that specific type if the original type is compatible.

```typescript
// Both calls to 'swim' and 'fly' are now okay.
let pet = getSmallPet();

if (isFish(pet)) {
  pet.swim();
} else {
  pet.fly();
}
```

Notice that TypeScript not only knows that `pet` is a `Fish` in the `if` branch; it also knows that in the `else` branch, you _don’t_ have a `Fish`, so you must have a `Bird`.

**Discriminated Unions**

Using a discriminant property to differentiate between types in a union.

```typescript
interface Circle {
  kind: 'circle';
  radius: number;
}

interface Square {
  kind: 'square';
  sideLength: number;
}

type Shape = Circle | Square;

function getArea(shape: Shape) {
  switch (shape.kind) {
    case 'circle':
      return Math.PI * shape.radius ** 2;
    case 'square':
      return shape.sideLength ** 2;
  }
}
```

TypeScript considers that to be a _discriminated union_, and can narrow out the members of the union. In this case, `kind` was that common property (which is what’s considered a _discriminant_ property of `Shape`). Checking whether the `kind` property was `"circle"` got rid of every type in `Shape` that didn’t have a `kind` property with the type `"circle"`. That narrowed `shape` down to the type `Circle`.

**Never Type**

When narrowing, you can reduce the options of a union to a point where you have removed all possibilities and have nothing left. In those cases, TypeScript will use a `never` type to represent a state which shouldn’t exist. The `never` type is assignable to every type; however, no type is assignable to `never` (except `never` itself). This means you can use narrowing and rely on `never` turning up to do exhaustive checking in a `switch` statement.

```textile
Important: For example, adding a `default` to our `getArea` function which tries to assign the shape to `never` will not raise an error when every possible case has been handled.

Adding a new member to the Shape union and not checking its case will cause a TypeScript error
```

```typescript
type Shape = Circle | Square;

function getArea(shape: Shape) {
  switch (shape.kind) {
    case "circle":
      return Math.PI * shape.radius ** 2;
    case "square":
      return shape.sideLength ** 2;
    default:
      const _exhaustiveCheck: never = shape;
      return _exhaustiveCheck;
  }
}
```

<hr>


